#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Hardware-Efficient Lattice Cryptography:
Deep Learning Surrogate Acceleration of ML-KEM via Ultra-Low Bitwidth
Quantization for Embedded Systems
------------------------------------------------------------------------
* REAL data only: All_GPUs.csv and Intel_CPUs.csv (no synthetic fallback).
* NO classic / baseline models. Every network trained here is a quantized
  deep surrogate (QAT with straight-through estimator).
* Evaluation: 5-fold out-of-fold (OOF5) predictions.
* Ablations: (A) bitwidth, (B) quantizer design, (C) architecture/width,
  (D) mixed precision (first/last layer).
* Proposed model = best quantized candidate across all ablations
  (highest OOF5 R2 among all quantized candidates within the MAX_KB lightweight budget).
* XAI: permutation importance, Integrated Gradients, PDP/ICE, (SHAP if installed).
* Everything is written to one folder (OUT_DIR) and, inside Jupyter, shown inline.

Run:   python lattice_pqc_surrogate.py          (or  %run lattice_pqc_surrogate.py)
Env:   DATA_DIR=<folder with the CSVs>  OUT_DIR=<output folder>  QUICK=1 (smoke test)
"""
import os, re, sys, json, math, copy, time, warnings
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib
IN_NB = "ipykernel" in sys.modules
if not IN_NB:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.model_selection import KFold   # used only for fold indices

warnings.filterwarnings("ignore")
torch.set_num_threads(max(1, (os.cpu_count() or 2) // 2))

# ----------------------------------------------------------------------------
# 0. CONFIG
# ----------------------------------------------------------------------------
BASE = Path(os.environ.get(
    "DATA_DIR", "/Users/collinschimeleze/Desktop/Raw Project/Hardware-Efficient Lattice /archive"))
OUT = Path(os.environ.get("OUT_DIR", str(BASE.parent / "outputs")))
QUICK = os.environ.get("QUICK", "0") == "1"
SEED = 42
N_FOLDS = 5
EPOCHS = 30 if QUICK else 150
PATIENCE = 12 if QUICK else 30
BATCH = 128
TOL = 0.002           # R2_log tolerance used by the greedy ablation stages (A->B->C->D)
MAX_KB = float(os.environ.get("MAX_KB", 2.5))   # lightweight budget (model memory) for the FINAL pick

# (file, target column, columns to drop). Targets are real columns of each CSV.
DATASETS = {
    "GPU": dict(file="All_GPUs.csv", target="Texture_Rate",
                drop=["Name", "Pixel_Rate", "Resolution_WxH"]),
    "CPU": dict(file="Intel_CPUs.csv", target="TDP",
                drop=["Processor_Number", "Product_Collection"]),
}
# Analytical Cortex-M4 cost model (cycles per MAC). ASSUMPTIONS - validate on target board.
CYC_PER_MAC = {8: 0.75, 6: 0.75, 5: 0.75, 4: 0.95, 3: 1.00, 2: 0.60, 1: 0.12}
CYC_PER_NEURON = 20      # requantisation / activation overhead per output neuron
FP32_CYC_PER_MAC = 3.0   # cost REFERENCE (M4F FMA incl. loads); no model is trained for it

OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"figure.dpi": 110, "axes.grid": True, "grid.alpha": .3,
                     "axes.spines.top": False, "axes.spines.right": False})


def save_fig(fig, folder, name):
    d = folder / "figures"; d.mkdir(parents=True, exist_ok=True)
    fig.savefig(d / f"{name}.png", dpi=200, bbox_inches="tight")
    if IN_NB:
        plt.show()
    plt.close(fig)


# ----------------------------------------------------------------------------
# 1. REAL DATA LOADING / CLEANING
# ----------------------------------------------------------------------------
def resolve(name):
    for c in (BASE / name, BASE / (" " + name)):          # your path has a leading space
        if c.exists():
            return c
    for root in (BASE, BASE.parent, Path.cwd()):
        if root.exists():
            for p in root.rglob("*.csv"):
                if p.name.strip().lower() == name.lower():
                    return p
    raise FileNotFoundError(f"{name} not found under {BASE}. Set DATA_DIR to the folder holding it.")


UNIT = {"ghz": 1000.0, "mhz": 1.0, "tb": 1024.0 * 1024, "gb": 1024.0, "mb": 1.0, "kb": 1 / 1024}
NUM_RE = re.compile(r"(-?\d[\d,]*\.?\d*)\s*(ghz|mhz|tb|gb|mb|kb)?", re.I)
NULL_RE = re.compile(r"^(|n/a|na|nan|none|-|unknown.*|\s*)$", re.I)


def parse_val(v):
    if pd.isna(v):
        return np.nan
    m = NUM_RE.search(str(v))
    if not m:
        return np.nan
    x = float(m.group(1).replace(",", ""))
    u = m.group(2)
    return x * UNIT[u.lower()] if u else x


def parse_year(v):
    s = str(v)
    m = re.search(r"(19|20)\d\d", s)
    if m:
        return float(m.group(0))
    m = re.search(r"'(\d\d)", s)
    return 2000.0 + float(m.group(1)) if m else np.nan


def build_table(df, target, drop):
    df = df.copy()
    df.columns = [c.strip() for c in df.columns]
    for c in df.columns:
        if df[c].dtype == object:
            s = df[c].astype(str).str.strip()
            df[c] = s.where(~s.str.match(NULL_RE), np.nan)
    y = df[target].map(parse_val)
    keep = y.notna() & (y > 0)
    df, y = df[keep].reset_index(drop=True), y[keep].reset_index(drop=True)
    num, cats = {}, {}
    for c in df.columns:
        if c == target or c in drop or df[c].isna().mean() > 0.6:
            continue
        s = df[c]
        if "date" in c.lower():
            yr = s.map(parse_year)
            if yr.notna().sum() > 20:
                num[c + "_year"] = yr
            continue
        if s.dtype != object:
            num[c] = s.astype(float); continue
        nn_ = s.dropna().astype(str)
        starts_num = nn_.str.match(r"^[\$€£]?\s*-?\d").mean()
        if starts_num >= 0.7:
            num[c] = s.map(parse_val)
        elif s.nunique() <= 40:
            top = s.value_counts().index[:10]
            cats[c] = s.where(s.isin(top), "Other").fillna("Missing")
    num = pd.DataFrame(num)
    num = num.loc[:, num.nunique() > 1]
    cat = pd.get_dummies(pd.DataFrame(cats), prefix_sep="=", dtype=float) if cats else pd.DataFrame(index=df.index)
    return num, cat, y


def prepare_split(num, cat, y, tr, te, skewed, miss_cols):
    N = num.copy()
    for c in skewed:
        N[c] = np.log1p(N[c].clip(lower=0))
    med = N.iloc[tr].median().fillna(0)
    ind = N[miss_cols].isna().astype(float).values if miss_cols else np.zeros((len(N), 0))
    Nf = N.fillna(med)
    mu = Nf.iloc[tr].mean(); sd = Nf.iloc[tr].std().replace(0, 1).fillna(1)
    Z = ((Nf - mu) / sd).clip(-5, 5).values
    X = np.hstack([Z, ind, cat.values]).astype(np.float32)
    names = list(num.columns) + [c + "_missing" for c in miss_cols] + list(cat.columns)
    ylog = np.log1p(y.values)
    my, sy = ylog[tr].mean(), ylog[tr].std() + 1e-9
    return dict(Xtr=X[tr], ytr=((ylog[tr] - my) / sy).astype(np.float32), Xte=X[te],
                yte_raw=y.values[te], te=te, my=my, sy=sy, names=names)


def make_folds(num, cat, y):
    skew = num.skew()
    skewed = [c for c in num.columns if skew[c] > 2 and num[c].min() >= 0]
    miss_cols = [c for c in num.columns if num[c].isna().mean() >= 0.05]
    kf = KFold(N_FOLDS, shuffle=True, random_state=SEED)
    folds = [prepare_split(num, cat, y, tr, te, skewed, miss_cols) for tr, te in kf.split(num)]
    full = prepare_split(num, cat, y, np.arange(len(num)), np.arange(min(10, len(num))), skewed, miss_cols)
    return folds, full


# ----------------------------------------------------------------------------
# 2. QUANTIZATION-AWARE DEEP SURROGATE (no classic / baseline models)
# ----------------------------------------------------------------------------
def grad_scale(x, g):
    return (x - x * g).detach() + x * g


def round_ste(x):
    return (x.round() - x).detach() + x


class WQ(nn.Module):
    """Symmetric weight quantiser. 1-bit = binary (sign*mean|w|), 2-bit = ternary,
    >=3-bit = uniform. learn=True -> LSQ learnable step; False -> min/max step.
    per_ch=True -> per-output-channel scale."""
    def __init__(self, w, bits, per_ch, learn):
        super().__init__()
        self.bits, self.per_ch, self.learn = bits, per_ch, learn
        self.qmax = 1 if bits == 1 else 2 ** (bits - 1) - 1
        if bits > 1 and learn:
            a = w.abs().mean(dim=1, keepdim=True) if per_ch else w.abs().mean().view(1, 1)
            self.scale = nn.Parameter((2 * a / math.sqrt(self.qmax)).clone())

    def _scale(self, w):
        if self.learn:
            return grad_scale(self.scale.abs() + 1e-8, 1.0 / math.sqrt(w.numel() * self.qmax))
        m = w.abs().amax(dim=1, keepdim=True) if self.per_ch else w.abs().max()
        return (m / self.qmax).detach().clamp_min(1e-8)

    def forward(self, w):
        if self.bits == 1:
            a = w.abs().mean(dim=1, keepdim=True) if self.per_ch else w.abs().mean()
            return w + (torch.sign(w) * a - w).detach()
        sc = self._scale(w)
        return round_ste(torch.clamp(w / sc, -self.qmax, self.qmax)) * sc

    @torch.no_grad()
    def ints(self, w):
        if self.bits == 1:
            a = w.abs().mean(dim=1, keepdim=True) if self.per_ch else w.abs().mean().view(1, 1)
            return torch.where(w >= 0, 1, -1).to(torch.int8), a
        sc = self._scale(w)
        return torch.clamp(torch.round(w / sc), -self.qmax, self.qmax).to(torch.int8), sc


class AQ(nn.Module):
    """Activation quantiser with (learnable or fixed) clipping value."""
    def __init__(self, bits, signed, learn, init):
        super().__init__()
        self.learn = learn
        self.qmin, self.qmax = (-(2 ** (bits - 1) - 1), 2 ** (bits - 1) - 1) if signed else (0, 2 ** bits - 1)
        a = torch.tensor(float(init))
        if learn:
            self.alpha = nn.Parameter(a)
        else:
            self.register_buffer("alpha", a)

    def forward(self, x):
        sc = self.alpha.abs() / self.qmax
        if self.learn:
            sc = grad_scale(sc, 1.0 / math.sqrt(x.numel() * self.qmax))
        sc = sc.clamp_min(1e-8)
        return round_ste(torch.clamp(x / sc, self.qmin, self.qmax)) * sc


class QLinear(nn.Module):
    def __init__(self, i, o, bits, per_ch, learn):
        super().__init__()
        self.lin = nn.Linear(i, o)
        self.wq = WQ(self.lin.weight.data, bits, per_ch, learn)

    def forward(self, x):
        return F.linear(x, self.wq(self.lin.weight), self.lin.bias)


@dataclass(frozen=True)
class Cfg:
    wbits: int = 4
    abits: int = 4
    hidden: Tuple[int, ...] = (64, 32)
    per_ch: bool = True
    learn: bool = True
    head_bits: Optional[int] = None
    first_bits: Optional[int] = None

    @property
    def name(self):
        return (f"W{self.wbits}A{self.abits}|{'-'.join(map(str, self.hidden))}|"
                f"{'PC' if self.per_ch else 'PT'}-{'LSQ' if self.learn else 'MM'}|"
                f"f{self.first_bits or '_'}h{self.head_bits or '_'}")

    def layer_bits(self, n_layers):
        out = []
        for li in range(n_layers):
            b = self.wbits
            if li == 0 and self.first_bits: b = self.first_bits
            if li == n_layers - 1 and self.head_bits: b = self.head_bits
            out.append(b)
        return out


class QMLP(nn.Module):
    """Quantised deep surrogate: int8 input -> [QLinear -> ReLU -> act-quant]* -> QLinear."""
    def __init__(self, d_in, cfg):
        super().__init__()
        dims = [d_in, *cfg.hidden, 1]
        lb = cfg.layer_bits(len(dims) - 1)
        self.inq = AQ(8, True, cfg.learn, 5.0)
        self.layers = nn.ModuleList(QLinear(i, o, b, cfg.per_ch, cfg.learn)
                                    for (i, o), b in zip(zip(dims[:-1], dims[1:]), lb))
        self.aqs = nn.ModuleList(AQ(cfg.abits, False, cfg.learn, 6.0) for _ in dims[1:-1])

    def forward(self, x):
        h = self.inq(x)
        for i, l in enumerate(self.layers):
            h = l(h)
            if i < len(self.layers) - 1:
                h = self.aqs[i](F.relu(h))
        return h.squeeze(-1)


def model_cost(cfg, d_in):
    dims = [d_in, *cfg.hidden, 1]
    lb = cfg.layer_bits(len(dims) - 1)
    macs = params = wbytes = cyc = 0
    for (i, o), b in zip(zip(dims[:-1], dims[1:]), lb):
        macs += i * o; params += i * o + o
        wbytes += math.ceil(i * o * b / 8) + 4 * o + (4 * o if cfg.per_ch else 4)   # weights+bias+scales
        cyc += i * o * CYC_PER_MAC[b] + CYC_PER_NEURON * o
    wbytes += 4 * (len(dims) - 1) + 4
    return dict(params=params, macs=macs, bytes=wbytes, kb=wbytes / 1024, est_cycles=cyc,
                fp32_ref_cycles=macs * FP32_CYC_PER_MAC + CYC_PER_NEURON * sum(dims[1:]))


def fit(cfg, Xtr, ytr, seed):
    torch.manual_seed(seed); rng = np.random.RandomState(seed)
    perm = rng.permutation(len(Xtr)); nv = max(int(.1 * len(Xtr)), 20)
    va, tr = perm[:nv], perm[nv:]
    X, y = torch.tensor(Xtr), torch.tensor(ytr)
    model = QMLP(X.shape[1], cfg)
    opt = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, EPOCHS)
    best, best_sd, bad, hist = 1e9, None, 0, dict(train=[], val=[])
    for ep in range(EPOCHS):
        model.train(); idx = rng.permutation(tr); tl = 0
        for s in range(0, len(idx), BATCH):
            b = idx[s:s + BATCH]
            loss = F.smooth_l1_loss(model(X[b]), y[b], beta=0.5)
            opt.zero_grad(); loss.backward(); opt.step(); tl += loss.item() * len(b)
        sch.step(); model.eval()
        with torch.no_grad():
            vl = F.smooth_l1_loss(model(X[va]), y[va], beta=0.5).item()
        hist["train"].append(tl / len(tr)); hist["val"].append(vl)
        if vl < best - 1e-5:
            best, bad, best_sd = vl, 0, copy.deepcopy(model.state_dict())
        else:
            bad += 1
            if bad >= PATIENCE: break
    model.load_state_dict(best_sd); model.eval()
    return model, hist


def predict_raw(model, X, my, sy):
    with torch.no_grad():
        z = model(torch.tensor(X)).numpy()
    return np.clip(np.expm1(z * sy + my), 0, None)


def metrics(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    r2 = lambda a, b: 1 - ((a - b) ** 2).sum() / ((a - a.mean()) ** 2).sum()
    return dict(R2=r2(y, p), R2_log=r2(np.log1p(y), np.log1p(p)), RMSE=float(np.sqrt(np.mean((y - p) ** 2))),
                MAE=float(np.mean(np.abs(y - p))), MAPE=float(np.mean(np.abs(y - p) / y) * 100))


def run_cv(cfg, folds, d_in):
    n = sum(len(f["te"]) for f in folds); oof = np.zeros(n); yraw = np.zeros(n)
    fold_m, models, hists = [], [], []
    for k, f in enumerate(folds):
        m, h = fit(cfg, f["Xtr"], f["ytr"], SEED + k)
        p = predict_raw(m, f["Xte"], f["my"], f["sy"])
        oof[f["te"]] = p; yraw[f["te"]] = f["yte_raw"]
        fold_m.append(metrics(f["yte_raw"], p)); models.append(m); hists.append(h)
    allm = metrics(yraw, oof)
    fm = pd.DataFrame(fold_m)
    return dict(cfg=cfg, oof=oof, y=yraw, models=models, hists=hists, fold_metrics=fm,
                **allm, R2_log_std=fm["R2_log"].std(), **model_cost(cfg, d_in))


def pick_best(rows):
    mx = max(r["R2_log"] for r in rows)
    ok = [r for r in rows if r["R2_log"] >= mx - TOL]
    return min(ok, key=lambda r: (r["bytes"], -r["R2_log"]))


def pick_final(cache):
    """Proposed model = highest OOF5 R2 among ALL quantized candidates that fit the
    lightweight memory budget MAX_KB (fallback: smallest model if none fits)."""
    rows = list(cache.values())
    fit_ = [r for r in rows if r["kb"] <= MAX_KB]
    return max(fit_, key=lambda r: (r["R2"], -r["bytes"])) if fit_ else min(rows, key=lambda r: r["bytes"])


# ----------------------------------------------------------------------------
# 3. ABLATION STUDIES
# ----------------------------------------------------------------------------
def run_ablations(folds, d_in, log):
    cache, stages = {}, {}

    def go(cfg, stage):
        if cfg.name not in cache:
            t = time.time(); cache[cfg.name] = run_cv(cfg, folds, d_in)
            r = cache[cfg.name]
            log(f"   [{stage}] {cfg.name:<38} R2_log={r['R2_log']:.4f} R2={r['R2']:.4f} "
                f"RMSE={r['RMSE']:.3f} size={r['kb']:.2f}KB ({time.time()-t:.0f}s)")
        return cache[cfg.name]

    base = Cfg()
    # A: bitwidth
    stages["A_bitwidth"] = [go(Cfg(wbits=w, abits=a), "A") for w, a in
                            [(8, 8), (6, 6), (4, 4), (3, 3), (2, 4), (2, 2), (1, 4)]]
    bA = pick_best(stages["A_bitwidth"])["cfg"]
    # B: quantiser design at best bitwidth
    stages["B_quantizer"] = [go(Cfg(bA.wbits, bA.abits, per_ch=pc, learn=lr), "B")
                             for pc in (True, False) for lr in (True, False)]
    bB = pick_best(stages["B_quantizer"])["cfg"]
    # C: architecture / width / depth
    stages["C_architecture"] = [go(Cfg(bB.wbits, bB.abits, hidden=h, per_ch=bB.per_ch, learn=bB.learn), "C")
                                for h in [(16,), (32,), (32, 16), (64, 32), (128, 64), (64, 32, 16)]]
    bC = pick_best(stages["C_architecture"])["cfg"]
    # D: mixed precision
    stages["D_mixed_precision"] = [go(Cfg(bC.wbits, bC.abits, bC.hidden, bC.per_ch, bC.learn, hb, fb), "D")
                                   for fb in (None, 8) for hb in (None, 8)]
    return cache, stages


# ----------------------------------------------------------------------------
# 4. XAI
# ----------------------------------------------------------------------------
def permutation_importance(models, folds, reps=5):
    rng = np.random.RandomState(SEED); out = []
    for m, f in zip(models, folds):
        X = f["Xte"]; yz = (np.log1p(f["yte_raw"]) - f["my"]) / f["sy"]
        def mse(Xp):
            with torch.no_grad():
                return float(np.mean((m(torch.tensor(Xp)).numpy() - yz) ** 2))
        b = mse(X); imp = np.zeros((reps, X.shape[1]))
        for j in range(X.shape[1]):
            for r in range(reps):
                Xp = X.copy(); Xp[:, j] = rng.permutation(Xp[:, j]); imp[r, j] = mse(Xp) - b
        out.append(imp.mean(0))
    out = np.array(out)
    return out.mean(0), out.std(0)


def integrated_gradients(model, X, steps=32):
    x = torch.tensor(X); base = torch.zeros_like(x); tot = 0
    for a in (np.arange(steps) + .5) / steps:
        xi = (base + a * (x - base)).requires_grad_(True)
        g, = torch.autograd.grad(model(xi).sum(), xi); tot = tot + g
    return ((x - base) * tot / steps).detach().numpy()


def export_and_check(model, cfg, Xte, folder):
    arr, h = {}, model.inq(torch.tensor(Xte[:256])); layers = []
    for i, l in enumerate(model.layers):
        q, sc = l.wq.ints(l.lin.weight.data)
        arr[f"L{i}_q"] = q.numpy(); arr[f"L{i}_scale"] = sc.numpy(); arr[f"L{i}_bias"] = l.lin.bias.detach().numpy()
        layers.append((q.float() * sc, l.lin.bias.data))
    arr["input_clip"] = model.inq.alpha.detach().numpy()
    for i in range(len(model.aqs)):
        arr[f"act{i}_clip"] = model.aqs[i].alpha.detach().numpy()
    with torch.no_grad():
        for i, (W, b) in enumerate(layers):
            h = h @ W.T + b
            if i < len(layers) - 1: h = model.aqs[i](F.relu(h))
        diff = float((h.squeeze(-1) - model(torch.tensor(Xte[:256]))).abs().max())
    np.savez_compressed(folder / "proposed_model_int_weights.npz", **arr)
    return diff


# ----------------------------------------------------------------------------
# 5. PLOTS
# ----------------------------------------------------------------------------
def plot_eda(num, cat, y, folder, tag, target):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    ax[0].hist(y, 50, color="#4C72B0"); ax[0].set_title(f"{target} (raw)")
    ax[1].hist(np.log1p(y), 50, color="#55A868"); ax[1].set_title(f"log1p({target})")
    fig.suptitle(f"{tag}: target distribution"); save_fig(fig, folder, "eda_target_distribution")

    miss = num.isna().mean().sort_values(ascending=False).head(20)
    fig, ax = plt.subplots(figsize=(7, 5)); ax.barh(miss.index[::-1], miss.values[::-1] * 100, color="#C44E52")
    ax.set_xlabel("% missing"); ax.set_title(f"{tag}: missingness (numeric)"); save_fig(fig, folder, "eda_missingness")

    cor = num.corrwith(pd.Series(np.log1p(y))).abs().sort_values(ascending=False).head(20)
    cm = num[cor.index].corr()
    fig, ax = plt.subplots(figsize=(8, 7)); im = ax.imshow(cm.values, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cm))); ax.set_xticklabels(cm.columns, rotation=90, fontsize=7)
    ax.set_yticks(range(len(cm))); ax.set_yticklabels(cm.columns, fontsize=7); ax.grid(False)
    fig.colorbar(im); ax.set_title(f"{tag}: correlation of top-20 features"); save_fig(fig, folder, "eda_correlation_heatmap")

    fig, ax = plt.subplots(figsize=(7, 5)); ax.barh(cor.index[::-1], cor.values[::-1], color="#8172B2")
    ax.set_xlabel(f"|Pearson| with log1p({target})"); ax.set_title(f"{tag}: feature-target correlation")
    save_fig(fig, folder, "eda_feature_target_correlation")


def plot_ablation(rows, stage, folder):
    names = [r["cfg"].name for r in rows]
    fig, ax = plt.subplots(1, 2, figsize=(13, 0.5 * len(rows) + 2.5))
    ax[0].barh(names, [r["R2_log"] for r in rows], xerr=[r["R2_log_std"] for r in rows], color="#4C72B0")
    lo = min(r["R2_log"] for r in rows); ax[0].set_xlim(max(0, lo - .05), 1.0)
    ax[0].set_xlabel("OOF5 R2 (log scale)"); ax[0].set_title(f"Ablation {stage}: accuracy")
    ax[1].barh(names, [r["kb"] for r in rows], color="#DD8452"); ax[1].set_yticklabels([])
    ax[1].set_xlabel("model memory (KB)"); ax[1].set_title("footprint")
    save_fig(fig, folder, f"ablation_{stage}")


def plot_pareto(cache, prop, folder):
    fig, ax = plt.subplots(1, 2, figsize=(13, 5))
    for k, key in enumerate(["kb", "est_cycles"]):
        for r in cache.values():
            ax[k].scatter(r[key], r["R2_log"], s=40, c=[r["cfg"].wbits], cmap="viridis", vmin=1, vmax=8)
        ax[k].scatter(prop[key], prop["R2_log"], s=300, marker="*", c="red", label="proposed", zorder=5)
        ax[k].set_xlabel("memory (KB)" if key == "kb" else "est. Cortex-M4 cycles / inference")
        ax[k].set_ylabel("OOF5 R2 (log)"); ax[k].set_xscale("log"); ax[k].legend()
    ax[0].set_title("Accuracy vs memory (colour = weight bits)"); ax[1].set_title("Accuracy vs estimated cycles")
    save_fig(fig, folder, "pareto_accuracy_vs_cost")


def plot_cycles(stageA, prop, folder):
    labs = [r["cfg"].name.split("|")[0] for r in stageA] + ["PROPOSED"]
    cyc = [r["est_cycles"] for r in stageA] + [prop["est_cycles"]]
    ref = prop["fp32_ref_cycles"]
    fig, ax = plt.subplots(figsize=(9, 4)); bars = ax.bar(labs, cyc, color=["#4C72B0"] * len(stageA) + ["#C44E52"])
    ax.axhline(ref, ls="--", c="k", label=f"FP32 cost reference (analytical): {ref:,.0f}")
    ax.set_ylabel("est. cycles / inference"); ax.set_yscale("log"); ax.legend()
    ax.set_title("Estimated embedded cost (Cortex-M4 analytical model; verify on hardware)")
    save_fig(fig, folder, "estimated_cycles")


def plot_proposed(prop, folder, tag):
    y, p = prop["y"], prop["oof"]
    fig, ax = plt.subplots(figsize=(5.5, 5.5)); ax.scatter(y, p, s=8, alpha=.5)
    lim = [min(y.min(), p.min()), max(y.max(), p.max())]; ax.plot(lim, lim, "r--")
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel("actual"); ax.set_ylabel("OOF5 predicted")
    ax.set_title(f"{tag}: proposed model, R2={prop['R2']:.3f}, R2(log)={prop['R2_log']:.3f}")
    save_fig(fig, folder, "proposed_oof_pred_vs_actual")

    res = p - y
    fig, ax = plt.subplots(1, 2, figsize=(11, 4)); ax[0].hist(res, 60, color="#55A868"); ax[0].set_title("OOF residuals")
    ax[1].scatter(p, res, s=7, alpha=.5); ax[1].axhline(0, c="r"); ax[1].set_xscale("log")
    ax[1].set_title("residual vs predicted"); save_fig(fig, folder, "proposed_residuals")

    fm = prop["fold_metrics"]
    fig, ax = plt.subplots(1, 3, figsize=(12, 3.5))
    for a, m in zip(ax, ["R2_log", "RMSE", "MAPE"]):
        a.bar(range(1, N_FOLDS + 1), fm[m], color="#8172B2"); a.set_title(m); a.set_xlabel("fold")
    save_fig(fig, folder, "proposed_per_fold_metrics")

    q = pd.qcut(y, 10, duplicates="drop"); e = pd.Series(np.abs(res) / y * 100).groupby(q).mean()
    fig, ax = plt.subplots(figsize=(8, 3.8)); ax.bar(range(len(e)), e.values, color="#DD8452")
    ax.set_xlabel("target decile (low -> high)"); ax.set_ylabel("MAPE %"); ax.set_title("Error by target decile")
    save_fig(fig, folder, "proposed_error_by_decile")

    fig, ax = plt.subplots(figsize=(7, 4))
    for k, h in enumerate(prop["hists"]):
        ax.plot(h["train"], c=f"C{k}", alpha=.6); ax.plot(h["val"], c=f"C{k}", ls="--")
    ax.set_yscale("log"); ax.set_xlabel("epoch"); ax.set_ylabel("Huber loss")
    ax.set_title("QAT learning curves (solid=train, dashed=val; 5 folds)"); save_fig(fig, folder, "proposed_learning_curves")


def plot_weight_levels(model, folder):
    n = len(model.layers); fig, ax = plt.subplots(1, n, figsize=(3.6 * n, 3.4))
    ax = np.atleast_1d(ax)
    for i, l in enumerate(model.layers):
        q, _ = l.wq.ints(l.lin.weight.data); v, c = np.unique(q.numpy(), return_counts=True)
        ax[i].bar(v.astype(str), c / c.sum() * 100, color="#4C72B0"); ax[i].set_title(f"layer {i}: {l.wq.bits}-bit levels")
        ax[i].set_ylabel("% weights")
    fig.suptitle("Integer weight-level usage of proposed model"); save_fig(fig, folder, "proposed_weight_levels")
    fig, ax = plt.subplots(1, n, figsize=(3.6 * n, 3.2)); ax = np.atleast_1d(ax)
    for i, l in enumerate(model.layers):
        ax[i].hist(l.lin.weight.detach().numpy().ravel(), 50, color="#C44E52"); ax[i].set_title(f"layer {i} latent weights")
    save_fig(fig, folder, "proposed_latent_weight_hist")


def plot_xai(prop, folds, full_model, full, names, folder, num_feat_idx):
    models = prop["models"]
    pi, pis = permutation_importance(models, folds)
    top = np.argsort(pi)[::-1][:15]
    fig, ax = plt.subplots(figsize=(7, 5)); ax.barh([names[i] for i in top][::-1], pi[top][::-1],
                                                    xerr=pis[top][::-1], color="#4C72B0")
    ax.set_xlabel("increase in standardised MSE when permuted"); ax.set_title("Permutation importance (held-out folds)")
    save_fig(fig, folder, "xai_permutation_importance")

    atts, Xs = [], []
    for m, f in zip(models, folds):
        atts.append(integrated_gradients(m, f["Xte"])); Xs.append(f["Xte"])
    A, X = np.vstack(atts), np.vstack(Xs); mabs = np.abs(A).mean(0); ti = np.argsort(mabs)[::-1][:15]
    fig, ax = plt.subplots(figsize=(7, 5)); ax.barh([names[i] for i in ti][::-1], mabs[ti][::-1], color="#55A868")
    ax.set_xlabel("mean |Integrated Gradients|"); ax.set_title("Integrated Gradients global importance")
    save_fig(fig, folder, "xai_integrated_gradients_bar")

    t10 = ti[:10]; rng = np.random.RandomState(0)
    fig, ax = plt.subplots(figsize=(8, 5.5))
    for r, j in enumerate(t10[::-1]):
        v = X[:, j]; c = (v - v.min()) / (np.ptp(v) + 1e-9)
        sc = ax.scatter(A[:, j], r + rng.uniform(-.3, .3, len(v)), c=c, cmap="coolwarm", s=6, alpha=.6)
    ax.set_yticks(range(len(t10))); ax.set_yticklabels([names[j] for j in t10[::-1]])
    fig.colorbar(sc, label="feature value (low -> high)"); ax.axvline(0, c="k", lw=.6)
    ax.set_xlabel("attribution (standardised log-target units)"); ax.set_title("Integrated Gradients (beeswarm-style)")
    save_fig(fig, folder, "xai_integrated_gradients_beeswarm")

    fig, ax = plt.subplots(figsize=(5.2, 5)); ax.scatter(pi, mabs, s=18)
    for j in np.argsort(pi)[::-1][:6]: ax.annotate(names[j], (pi[j], mabs[j]), fontsize=7)
    ax.set_xlabel("permutation importance"); ax.set_ylabel("mean |IG|"); ax.set_title("Agreement of XAI methods")
    save_fig(fig, folder, "xai_method_agreement")

    pd.DataFrame(dict(feature=names, perm_importance=pi, perm_std=pis, mean_abs_IG=mabs)) \
        .sort_values("perm_importance", ascending=False).to_csv(folder / "xai_importances.csv", index=False)

    # PDP / ICE on final full-data model
    Xf = full["Xtr"]; sel = [j for j in top if j < num_feat_idx][:4]
    if sel:
        fig, ax = plt.subplots(1, len(sel), figsize=(4.2 * len(sel), 3.6)); ax = np.atleast_1d(ax)
        for a, j in zip(ax, sel):
            grid = np.linspace(np.percentile(Xf[:, j], 5), np.percentile(Xf[:, j], 95), 25)
            idx = np.random.RandomState(1).choice(len(Xf), min(60, len(Xf)), replace=False); curves = []
            for i in idx:
                xs = np.repeat(Xf[i:i + 1], len(grid), 0); xs[:, j] = grid
                with torch.no_grad(): curves.append(full_model(torch.tensor(xs)).numpy())
                a.plot(grid, curves[-1], c="grey", alpha=.2, lw=.8)
            a.plot(grid, np.mean(curves, 0), c="r", lw=2); a.set_title(names[j], fontsize=9)
            a.set_xlabel("standardised value"); a.set_ylabel("pred (std. log-target)")
        fig.suptitle("PDP (red) + ICE (grey), proposed model"); save_fig(fig, folder, "xai_pdp_ice")

    try:                                                   # optional SHAP
        import shap
        bg = Xf[np.random.RandomState(2).choice(len(Xf), min(50, len(Xf)), replace=False)]
        ex = Xf[np.random.RandomState(3).choice(len(Xf), min(150, len(Xf)), replace=False)]
        f = lambda z: full_model(torch.tensor(z.astype(np.float32))).detach().numpy()
        sv = shap.KernelExplainer(f, bg).shap_values(ex, nsamples=100)
        plt.figure(); shap.summary_plot(sv, ex, feature_names=names, show=False, max_display=15)
        save_fig(plt.gcf(), folder, "xai_shap_summary")
    except Exception as e:
        print("   (SHAP skipped:", str(e)[:80], ")")
    return pi, mabs


# ----------------------------------------------------------------------------
# 6. MAIN
# ----------------------------------------------------------------------------
def run_dataset(tag, spec):
    folder = OUT / tag; folder.mkdir(parents=True, exist_ok=True)
    logf = open(folder / "log.txt", "w")
    def log(s):
        print(s); logf.write(s + "\n"); logf.flush()

    path = resolve(spec["file"]); log(f"\n===== {tag}: {path} =====")
    df = pd.read_csv(path, encoding_errors="replace", skipinitialspace=True)
    log(f"raw shape {df.shape}")
    num, cat, y = build_table(df, spec["target"], spec["drop"])
    log(f"usable rows {len(y)} | numeric feats {num.shape[1]} | one-hot feats {cat.shape[1]} | target {spec['target']}")
    plot_eda(num, cat, y, folder, tag, spec["target"])
    folds, full = make_folds(num, cat, y); d_in = folds[0]["Xtr"].shape[1]
    names = full["names"]; n_num = num.shape[1]

    cache, stages = run_ablations(folds, d_in, log)
    for st, rows in stages.items():
        plot_ablation(rows, st, folder)
    table = pd.DataFrame([{k: v for k, v in dict(name=r["cfg"].name, wbits=r["cfg"].wbits, abits=r["cfg"].abits,
                           hidden=str(r["cfg"].hidden), R2_log=r["R2_log"], R2_log_std=r["R2_log_std"], R2=r["R2"],
                           RMSE=r["RMSE"], MAE=r["MAE"], MAPE=r["MAPE"], params=r["params"], kb=r["kb"],
                           est_cycles=r["est_cycles"]).items()} for r in cache.values()]) \
        .sort_values("R2_log", ascending=False)
    table.to_csv(folder / "ablation_results.csv", index=False)
    for st, rows in stages.items():
        pd.DataFrame([dict(name=r["cfg"].name, R2_log=r["R2_log"], R2=r["R2"], RMSE=r["RMSE"], kb=r["kb"])
                      for r in rows]).to_csv(folder / f"ablation_{st}.csv", index=False)

    prop = pick_final(cache); pc = prop["cfg"]
    log(f"\n>>> PROPOSED MODEL ({tag}): {pc.name}\n    OOF5 R2={prop['R2']:.4f} R2_log={prop['R2_log']:.4f} "
        f"RMSE={prop['RMSE']:.3f} MAE={prop['MAE']:.3f} MAPE={prop['MAPE']:.1f}% | "
        f"{prop['params']} params, {prop['kb']:.2f} KB, ~{prop['est_cycles']:.0f} cycles (est.)")
    pd.DataFrame(dict(row_index=np.arange(len(prop["y"])), actual=prop["y"], oof_pred=prop["oof"],
                      fold=np.concatenate([[k] * len(f["te"]) for k, f in enumerate(folds)])[np.argsort(
                          np.concatenate([f["te"] for f in folds]))])).to_csv(folder / "oof5_predictions.csv", index=False)
    prop["fold_metrics"].to_csv(folder / "proposed_fold_metrics.csv", index=False)

    plot_pareto(cache, prop, folder); plot_cycles(stages["A_bitwidth"], prop, folder)
    plot_proposed(prop, folder, tag)

    # final deployable model on all data (same cfg)
    full_model, _ = fit(pc, full["Xtr"], full["ytr"], SEED)
    plot_weight_levels(full_model, folder)
    diff = export_and_check(full_model, pc, full["Xtr"], folder)
    log(f"    integer-export consistency (max |diff|): {diff:.2e}")
    pi, mabs = plot_xai(prop, folds, full_model, full, names, folder, n_num)
    torch.save(full_model.state_dict(), folder / "proposed_model_state.pt")
    json.dump(dict(dataset=tag, target=spec["target"], config=pc.name, features=names,
                   metrics={k: float(prop[k]) for k in ["R2", "R2_log", "RMSE", "MAE", "MAPE"]},
                   cost={k: float(prop[k]) for k in ["params", "macs", "bytes", "kb", "est_cycles", "fp32_ref_cycles"]},
                   cost_assumptions=dict(cycles_per_mac=CYC_PER_MAC, per_neuron=CYC_PER_NEURON)),
              open(folder / "proposed_model_summary.json", "w"), indent=2)
    logf.close()
    return dict(dataset=tag, target=spec["target"], proposed=pc.name, R2=prop["R2"], R2_log=prop["R2_log"],
                RMSE=prop["RMSE"], MAE=prop["MAE"], MAPE=prop["MAPE"], KB=prop["kb"], est_cycles=prop["est_cycles"])


if __name__ == "__main__":
    t0 = time.time(); rows = []
    for tag, spec in DATASETS.items():
        rows.append(run_dataset(tag, spec))
    summ = pd.DataFrame(rows); summ.to_csv(OUT / "summary_proposed_models.csv", index=False)
    print("\n", summ.to_string(index=False)); print(f"\nAll outputs in: {OUT}  ({(time.time()-t0)/60:.1f} min)")
