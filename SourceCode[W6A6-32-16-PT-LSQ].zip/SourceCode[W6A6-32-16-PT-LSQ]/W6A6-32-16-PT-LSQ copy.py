#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Builds the research article (MS Word) from the outputs of lattice_pqc_surrogate.py.
  python build_article.py
Env: OUT_DIR = folder produced by the pipeline (contains GPU/ and CPU/ sub-folders)
     ARTICLE  = output .docx path
Figures are taken from OUT_DIR/<GPU|CPU>/figures/*.png. If a PNG is missing, a figure is
re-drawn from the logged ablation numbers (ablation / Pareto / cycles) or a labelled
placeholder box is inserted. Per-fold and XAI tables are read from the CSVs when present.
Citations [n], equation numbers, table and figure numbers are assigned automatically
in order of appearance.
"""
import os, re, math, tempfile
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

OUT = Path(os.environ.get("OUT_DIR", "/Users/collinschimeleze/Desktop/Raw Project/Hardware-Efficient Lattice /outputs"))
ARTICLE = Path(os.environ.get("ARTICLE", str(OUT / "Research_Article_W6A6-32-16-PT-LSQ.docx")))
TMP = Path(tempfile.mkdtemp())
FONT = "Times New Roman"
LINE = float(os.environ.get("LINE_SPACING", 1.15))
FIG_W = float(os.environ.get("FIG_WIDTH", 4.9))

# ----------------------------------------------------------------------------- DATA (from the logged runs)
D_IN = {"GPU": 63, "CPU": 74}
STAGES = {
 "GPU": {
  "A_bitwidth": [("W8A8|64-32|PC-LSQ|f_h_",.9914,.9770,13.759),("W6A6|64-32|PC-LSQ|f_h_",.9907,.9803,12.735),
    ("W4A4|64-32|PC-LSQ|f_h_",.9892,.9792,13.086),("W3A3|64-32|PC-LSQ|f_h_",.9856,.9754,14.223),
    ("W2A4|64-32|PC-LSQ|f_h_",.9814,.9784,13.342),("W2A2|64-32|PC-LSQ|f_h_",.9684,.9523,19.824),
    ("W1A4|64-32|PC-LSQ|f_h_",.9753,.9699,15.732)],
  "B_quantizer": [("W6A6|64-32|PC-LSQ|f_h_",.9907,.9803,12.735),("W6A6|64-32|PC-MM|f_h_",.9906,.9754,14.245),
    ("W6A6|64-32|PT-LSQ|f_h_",.9908,.9771,13.724),("W6A6|64-32|PT-MM|f_h_",.9902,.9749,14.385)],
  "C_architecture": [("W6A6|16|PT-LSQ|f_h_",.9888,.9718,15.232),("W6A6|32|PT-LSQ|f_h_",.9898,.9752,14.295),
    ("W6A6|32-16|PT-LSQ|f_h_",.9907,.9810,12.522),("W6A6|64-32|PT-LSQ|f_h_",.9908,.9771,13.724),
    ("W6A6|128-64|PT-LSQ|f_h_",.9918,.9799,12.866),("W6A6|64-32-16|PT-LSQ|f_h_",.9915,.9827,11.932)],
  "D_mixed_precision": [("W6A6|32|PT-LSQ|f_h_",.9898,.9752,14.295),("W6A6|32|PT-LSQ|f_h8",.9902,.9711,15.423),
    ("W6A6|32|PT-LSQ|f8h_",.9902,.9766,13.886),("W6A6|32|PT-LSQ|f8h8",.9898,.9605,18.038)]},
 "CPU": {
  "A_bitwidth": [("W8A8|64-32|PC-LSQ|f_h_",.9542,.9558,9.423),("W6A6|64-32|PC-LSQ|f_h_",.9508,.9540,9.615),
    ("W4A4|64-32|PC-LSQ|f_h_",.9499,.9499,10.034),("W3A3|64-32|PC-LSQ|f_h_",.9439,.9396,11.017),
    ("W2A4|64-32|PC-LSQ|f_h_",.9396,.9367,11.278),("W2A2|64-32|PC-LSQ|f_h_",.9255,.9175,12.875),
    ("W1A4|64-32|PC-LSQ|f_h_",.9274,.9280,12.026)],
  "B_quantizer": [("W8A8|64-32|PC-LSQ|f_h_",.9542,.9558,9.423),("W8A8|64-32|PC-MM|f_h_",.9537,.9559,9.409),
    ("W8A8|64-32|PT-LSQ|f_h_",.9514,.9545,9.562),("W8A8|64-32|PT-MM|f_h_",.9556,.9562,9.383)],
  "C_architecture": [("W8A8|16|PT-MM|f_h_",.9327,.9345,11.475),("W8A8|32|PT-MM|f_h_",.9421,.9471,10.308),
    ("W8A8|32-16|PT-MM|f_h_",.9449,.9509,9.933),("W8A8|64-32|PT-MM|f_h_",.9556,.9562,9.383),
    ("W8A8|128-64|PT-MM|f_h_",.9554,.9579,9.196),("W8A8|64-32-16|PT-MM|f_h_",.9496,.9537,9.642)],
  "D_mixed_precision": [("W8A8|64-32|PT-MM|f_h_",.9556,.9562,9.383),("W8A8|64-32|PT-MM|f_h8",.9556,.9562,9.383),
    ("W8A8|64-32|PT-MM|f8h_",.9556,.9562,9.383),("W8A8|64-32|PT-MM|f8h8",.9556,.9562,9.383)]},
}
CYC = {8: .75, 6: .75, 5: .75, 4: .95, 3: 1.0, 2: .6, 1: .12}
NEU, FP32C = 20, 3.0


def cost(name, d):
    m = re.match(r"W(\d)A(\d)\|([\d-]+)\|(P[CT])-(\w+)\|f(_|\d)h(_|\d)", name)
    w, a, hid, pc, q, f, h = m.groups(); w = int(w); hid = [int(x) for x in hid.split("-")]
    dims = [d, *hid, 1]; n = len(dims) - 1; kb = cyc = macs = 0; by = 0; params = sum(i * o + o for i, o in zip(dims[:-1], dims[1:]))
    for li, (i, o) in enumerate(zip(dims[:-1], dims[1:])):
        b = w
        if li == 0 and f != "_": b = int(f)
        if li == n - 1 and h != "_": b = int(h)
        macs += i * o; by += math.ceil(i * o * b / 8) + 4 * o + (4 * o if pc == "PC" else 4); cyc += i * o * CYC[b] + NEU * o
    by += 4 * n + 4
    return dict(kb=by / 1024, cyc=cyc, fp32=macs * FP32C + NEU * sum(dims[1:]), macs=macs, params=params)


# ----------------------------------------------------------------------------- REFERENCES (APA-style, numbered by appearance)
R = {
 "bos": "Bos, J., Ducas, L., Kiltz, E., Lepoint, T., Lyubashevsky, V., Schanck, J. M., Schwabe, P., Seiler, G., & Stehlé, D. (2018). CRYSTALS–Kyber: A CCA-secure module-lattice-based KEM. In Proceedings of the IEEE European Symposium on Security and Privacy (EuroS&P) (pp. 353–367). IEEE.",
 "fips203": "National Institute of Standards and Technology. (2024). Module-lattice-based key-encapsulation mechanism standard (FIPS 203). U.S. Department of Commerce. https://doi.org/10.6028/NIST.FIPS.203",
 "shor": "Shor, P. W. (1997). Polynomial-time algorithms for prime factorization and discrete logarithms on a quantum computer. SIAM Journal on Computing, 26(5), 1484–1509.",
 "regev": "Regev, O. (2009). On lattices, learning with errors, random linear codes, and cryptography. Journal of the ACM, 56(6), Article 34.",
 "lpr": "Lyubashevsky, V., Peikert, C., & Regev, O. (2013). On ideal lattices and learning with errors over rings. Journal of the ACM, 60(6), Article 43.",
 "ls": "Langlois, A., & Stehlé, D. (2015). Worst-case to average-case reductions for module lattices. Designs, Codes and Cryptography, 75(3), 565–599.",
 "alagic": "Alagic, G., Apon, D., Cooper, D., Dang, Q., Dang, T., Kelsey, J., Lichtinger, J., Miller, C., Moody, D., Peralta, R., Perlner, R., Robinson, A., Smith-Tone, D., & Liu, Y.-K. (2022). Status report on the third round of the NIST post-quantum cryptography standardization process (NISTIR 8413). National Institute of Standards and Technology.",
 "pqm4": "Kannwischer, M. J., Rijneveld, J., Schwabe, P., & Stoffelen, K. (2019). pqm4: Testing and benchmarking NIST PQC on ARM Cortex-M4. Cryptology ePrint Archive, Paper 2019/844.",
 "botros": "Botros, L., Kannwischer, M. J., & Schwabe, P. (2019). Memory-efficient high-speed implementation of Kyber on Cortex-M4. In Progress in Cryptology – AFRICACRYPT 2019 (LNCS 11627, pp. 209–228). Springer.",
 "alkim20": "Alkim, E., Bilgin, Y. A., Cenk, M., & Gérard, F. (2020). Cortex-M4 optimizations for {R,M}LWE schemes. IACR Transactions on Cryptographic Hardware and Embedded Systems, 2020(3), 336–357.",
 "newhope": "Alkim, E., Ducas, L., Pöppelmann, T., & Schwabe, P. (2016). Post-quantum key exchange—A new hope. In Proceedings of the 25th USENIX Security Symposium (pp. 327–343). USENIX Association.",
 "seiler": "Seiler, G. (2018). Faster AVX2 optimized NTT multiplication for Ring-LWE lattice cryptography. Cryptology ePrint Archive, Paper 2018/039.",
 "ct": "Cooley, J. W., & Tukey, J. W. (1965). An algorithm for the machine calculation of complex Fourier series. Mathematics of Computation, 19(90), 297–301.",
 "jacob": "Jacob, B., Kligys, S., Chen, B., Zhu, M., Tang, M., Howard, A., Adam, H., & Kalenichenko, D. (2018). Quantization and training of neural networks for efficient integer-arithmetic-only inference. In Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (pp. 2704–2713). IEEE.",
 "kris": "Krishnamoorthi, R. (2018). Quantizing deep convolutional networks for efficient inference: A whitepaper. arXiv:1806.08342.",
 "nagel": "Nagel, M., Fournarakis, M., Amjad, R. A., Bondarenko, Y., van Baalen, M., & Blankevoort, T. (2021). A white paper on neural network quantization. arXiv:2106.08295.",
 "hubara": "Hubara, I., Courbariaux, M., Soudry, D., El-Yaniv, R., & Bengio, Y. (2018). Quantized neural networks: Training neural networks with low precision weights and activations. Journal of Machine Learning Research, 18(187), 1–30.",
 "bc": "Courbariaux, M., Bengio, Y., & David, J.-P. (2015). BinaryConnect: Training deep neural networks with binary weights during propagations. In Advances in Neural Information Processing Systems 28 (pp. 3123–3131).",
 "xnor": "Rastegari, M., Ordonez, V., Redmon, J., & Farhadi, A. (2016). XNOR-Net: ImageNet classification using binary convolutional neural networks. In Computer Vision – ECCV 2016 (LNCS 9908, pp. 525–542). Springer.",
 "twn": "Li, F., Zhang, B., & Liu, B. (2016). Ternary weight networks. arXiv:1605.04711.",
 "dorefa": "Zhou, S., Wu, Y., Ni, Z., Zhou, X., Wen, H., & Zou, Y. (2016). DoReFa-Net: Training low bitwidth convolutional neural networks with low bitwidth gradients. arXiv:1606.06160.",
 "pact": "Choi, J., Wang, Z., Venkataramani, S., Chuang, P. I.-J., Srinivasan, V., & Gopalakrishnan, K. (2018). PACT: Parameterized clipping activation for quantized neural networks. arXiv:1805.06085.",
 "lsq": "Esser, S. K., McKinstry, J. L., Bablani, D., Appuswamy, R., & Modha, D. S. (2020). Learned step size quantization. In International Conference on Learning Representations (ICLR).",
 "ste": "Bengio, Y., Léonard, N., & Courville, A. (2013). Estimating or propagating gradients through stochastic neurons for conditional computation. arXiv:1308.3432.",
 "han": "Han, S., Mao, H., & Dally, W. J. (2016). Deep compression: Compressing deep neural networks with pruning, trained quantization and Huffman coding. In International Conference on Learning Representations (ICLR).",
 "cmsis": "Lai, L., Suda, N., & Chandra, V. (2018). CMSIS-NN: Efficient neural network kernels for Arm Cortex-M CPUs. arXiv:1801.06601.",
 "tflm": "David, R., Duke, J., Jain, A., Janapa Reddi, V., Jeffries, N., Li, J., Kreeger, N., Nappier, I., Natraj, M., Wang, T., Warden, P., & Rhodes, R. (2021). TensorFlow Lite Micro: Embedded machine learning for TinyML systems. Proceedings of Machine Learning and Systems, 3, 800–811.",
 "mlperf": "Banbury, C., Reddi, V. J., Torelli, P., Holleman, J., Jeffries, N., Király, C., Montino, P., Kanter, D., Ahmed, S., Pau, D., Thakker, U., Torrini, A., Warden, P., Cordaro, J., Di Guglielmo, G., Duarte, J., Gibellini, S., Parekh, V., Tran, H., … Zhu, Y. (2021). MLPerf Tiny benchmark. In Advances in Neural Information Processing Systems (Datasets and Benchmarks Track).",
 "ithemal": "Mendis, C., Renda, A., Amarasinghe, S., & Carbin, M. (2019). Ithemal: Accurate, portable and fast basic block throughput estimation using deep neural networks. In Proceedings of the 36th International Conference on Machine Learning (PMLR 97, pp. 4505–4515).",
 "nnmeter": "Zhang, L. L., Han, S., Wei, J., Zheng, N., Cao, T., Yang, Y., & Liu, Y. (2021). nn-Meter: Towards accurate latency prediction of deep-learning model inference on diverse edge devices. In Proceedings of the 19th ACM International Conference on Mobile Systems, Applications, and Services (MobiSys) (pp. 81–93). ACM.",
 "hwnas": "Li, C., Yu, Z., Fu, Y., Zhang, Y., Zhao, Y., You, H., Yu, Q., Wang, Y., Hao, C., & Lin, Y. (2021). HW-NAS-Bench: Hardware-aware neural architecture search benchmark. In International Conference on Learning Representations (ICLR).",
 "proxyless": "Cai, H., Zhu, L., & Han, S. (2019). ProxylessNAS: Direct neural architecture search on target task and hardware. In International Conference on Learning Representations (ICLR).",
 "roofline": "Williams, S., Waterman, A., & Patterson, D. (2009). Roofline: An insightful visual performance model for multicore architectures. Communications of the ACM, 52(4), 65–76.",
 "ig": "Sundararajan, M., Taly, A., & Yan, Q. (2017). Axiomatic attribution for deep networks. In Proceedings of the 34th International Conference on Machine Learning (PMLR 70, pp. 3319–3328).",
 "shap": "Lundberg, S. M., & Lee, S.-I. (2017). A unified approach to interpreting model predictions. In Advances in Neural Information Processing Systems 30 (pp. 4765–4774).",
 "fisher": "Fisher, A., Rudin, C., & Dominici, F. (2019). All models are wrong, but many are useful: Learning a variable's importance by studying an entire class of prediction models simultaneously. Journal of Machine Learning Research, 20(177), 1–81.",
 "pdp": "Friedman, J. H. (2001). Greedy function approximation: A gradient boosting machine. The Annals of Statistics, 29(5), 1189–1232.",
 "ice": "Goldstein, A., Kapelner, A., Bleich, J., & Pitkin, E. (2015). Peeking inside the black box: Visualizing statistical learning with plots of individual conditional expectation. Journal of Computational and Graphical Statistics, 24(1), 44–65.",
 "huber": "Huber, P. J. (1964). Robust estimation of a location parameter. The Annals of Mathematical Statistics, 35(1), 73–101.",
 "adamw": "Loshchilov, I., & Hutter, F. (2019). Decoupled weight decay regularization. In International Conference on Learning Representations (ICLR).",
 "stone": "Stone, M. (1974). Cross-validatory choice and assessment of statistical predictions. Journal of the Royal Statistical Society: Series B, 36(2), 111–147.",
 "torch": "Paszke, A., Gross, S., Massa, F., Lerer, A., Bradbury, J., Chanan, G., Killeen, T., Lin, Z., Gimelshein, N., Antiga, L., Desmaison, A., Köpf, A., Yang, E., DeVito, Z., Raison, M., Tejani, A., Chilamkurthi, S., Steiner, B., Fang, L., … Chintala, S. (2019). PyTorch: An imperative style, high-performance deep learning library. In Advances in Neural Information Processing Systems 32 (pp. 8024–8035).",
 "sklearn": "Pedregosa, F., Varoquaux, G., Gramfort, A., Michel, V., Thirion, B., Grisel, O., Blondel, M., Prettenhofer, P., Weiss, R., Dubourg, V., Vanderplas, J., Passos, A., Cournapeau, D., Brucher, M., Perrot, M., & Duchesnay, É. (2011). Scikit-learn: Machine learning in Python. Journal of Machine Learning Research, 12, 2825–2830.",
 "kaggle": "Sekkaf, I. (n.d.). Computer parts (CPUs and GPUs) [Data set]. Kaggle. https://www.kaggle.com/datasets/iliassekkaf/computerparts",
}

# ----------------------------------------------------------------------------- CONTENT
TITLE = "W6A6-32-16-PT-LSQ: An Ultra-Low-Bitwidth Deep Learning Surrogate for Hardware-Efficient ML-KEM Acceleration in Embedded Systems"
ABSTRACT = ("Post-quantum key encapsulation based on module lattices (ML-KEM) is dominated by polynomial and matrix–vector arithmetic, which is costly on "
 "memory-constrained microcontrollers. We study a deep learning surrogate that maps hardware specifications to hardware capability indicators, so that "
 "deployment decisions for lattice workloads can be made with a very small on-device model. We propose W6A6-32-16-PT-LSQ, a two-hidden-layer (32-16) quantized network "
 "with 6-bit weights and 6-bit activations, per-tensor learned step-size quantization, and an 8-bit input stage. The model is trained with quantization-aware training and evaluated "
 "with five-fold out-of-fold (OOF5) validation on two real datasets: 2,861 GPU records (target: texture rate) and 2,216 Intel CPU records (target: thermal design power). "
 "On the GPU data the proposed network reaches an OOF5 R² of 0.981 (R² on the log scale 0.991, RMSE 12.52, MAE 4.46) with 2,593 parameters and a 2.08 KB footprint. "
 "It was benchmarked against alternative quantized configurations spanning 1–8 bits, four quantizer designs, six architectures and four mixed-precision settings. "
 "An analytical Cortex-M4 cost model suggests roughly 2.9 × 10³ cycles per inference, about three times fewer than a floating-point cost reference. "
 "Integrated Gradients, permutation importance, partial dependence and SHAP plots are provided to inspect the learned behaviour. "
 "Cycle figures are analytical estimates, and ML-KEM kernels were not executed on hardware in this study.")
KEYWORDS = "ML-KEM; lattice-based cryptography; quantization-aware training; deep learning surrogate; embedded systems; hardware acceleration; explainable AI; out-of-fold validation"

B = []   # blocks
def h1(t): B.append(("h1", t))
def h2(t): B.append(("h2", t))
def p(t): B.append(("p", t))
def bul(items): B.append(("bul", items))
def eq(key, expr): B.append(("eq", key, expr))
def tbl(key, cap, head, rows, widths=None): B.append(("tbl", key, cap, head, rows, widths))
def fig(key, cap, ds, fname): B.append(("fig", key, cap, ds, fname))

# ---- 1 INTRODUCTION
h1("1. Introduction")
h2("1.1 Background and motivation")
p("Public-key cryptography deployed today relies on factoring and discrete logarithms, both of which are solvable in polynomial time on a sufficiently large quantum computer, as shown by Shor {c:shor}. "
  "The NIST post-quantum standardization effort, summarized by Alagic et al. {c:alagic}, led to the standardization of a module-lattice key-encapsulation mechanism, ML-KEM, in FIPS 203 {c:fips203}. "
  "ML-KEM derives from CRYSTALS–Kyber, introduced by Bos et al. {c:bos}, and its security is based on module learning with errors, building on the work of Regev {c:regev}, Lyubashevsky et al. {c:lpr} and Langlois and Stehlé {c:ls}. "
  "Its operations are dominated by arithmetic in the ring R_{q} = ℤ_{q}[X]/(X^{n}+1) with q = 3329 and n = 256, and by matrix–vector products over R_{q}^{k×k} with k ∈ {2, 3, 4}.")
p("Microcontrollers such as the Arm Cortex-M4 are a reference platform for evaluating post-quantum schemes {c:pqm4}. Work on this platform has concentrated on handcrafted assembly, memory reduction and fast number-theoretic transforms "
  "{c:botros}, {c:alkim20}. A complementary question is how a designer can estimate, early and cheaply, whether a candidate device can host a lattice workload at all. "
  "Hardware-aware neural surrogates have been used for this kind of estimation in other settings {c:ithemal}, {c:nnmeter}, but the surrogate itself is rarely made small enough to run on the same class of device it describes.")
p("In this paper we study such a surrogate. We train a deep network that maps a device specification vector to a hardware capability indicator and compress it with ultra-low-bitwidth quantization so that it fits in a few kilobytes. "
  "We evaluate it on two real hardware-specification datasets and examine its behaviour with explainable AI (XAI) tools. We use the surrogate as a screening aid for lattice workloads; direct replacement of ML-KEM arithmetic by a neural network is outside the scope of this work.")
h2("1.2 Problem statement")
p("Let x_{i} ∈ ℝ^{d} be the specification vector of device i (clock rates, core counts, memory sizes, process node and categorical descriptors) and let y_{i} > 0 be a measured capability indicator. "
  "We assume an unknown mapping with additive noise, in the spirit of performance-model formulations such as the Roofline model {c:roofline}:")
eq("map", "y_{i} = g(x_{i}) + ε_{i},    g: ℝ^{d} → ℝ_{>0}")
p("We seek a surrogate whose weights are restricted to b_{l}-bit integers in each layer l. Following integer-arithmetic-only inference {c:jacob}, the quantized surrogate is")
eq("surr", "ŷ = f( x ; Q_{b}(θ), α ),    b = (b_{1}, …, b_{L})")
p("where θ are latent weights, Q_{b} is the layer-wise quantizer and α are activation clipping values. The design choice is the configuration c = (b, a, h, π, λ): weight bits, activation bits, hidden widths, scale granularity π (per-tensor or per-channel) and step-size rule λ (learned or min–max). "
  "Hardware-aware search methods usually treat latency or memory as a penalty or as a secondary objective {c:proxyless}, {c:hwnas}. We instead state the problem as an accuracy maximization under explicit device budgets:")
eq("prob", "c* = argmax_{c ∈ 𝒞}  R²_{OOF}(c)    subject to    M(c) ≤ B_{mem},   Ĉ(c) ≤ τ_{cyc}")
p("where R²_{OOF} is computed from out-of-fold predictions, M(c) is the memory footprint in bytes and Ĉ(c) is the estimated cycle count per inference. "
  "In this study the memory constraint is enforced during selection and the cycle estimate is reported afterwards. The downstream use is a workload-to-capacity ratio for ML-KEM. "
  "With k the module rank and N_{t} the number of forward and inverse number-theoretic transforms (NTT) {c:ct}, {c:seiler} in the operation of interest, the operator count is")
eq("omega", "Ω(k, n) = k² · n + N_{t} · (n/2) · log_{2}(n/2)")
p("and the screening ratio of a device with specification x is")
eq("ratio", "r̂(x) = Ω(k, n) / ŷ(x)")
p("We use Eq. {e:ratio} only to rank devices; it has not been validated against measured ML-KEM timings.  Modular reduction in practice is not modelled here. "
  "The novelty of the formulation is the joint treatment of precision, scale granularity, step-size rule and mixed precision under a single budgeted objective (Eq. {e:prob}), carried unchanged into the selection rule of Section 4.7 (Eq. {e:final}).")
h2("1.3 Research questions")
bul(["RQ1: How much accuracy is lost as the weight/activation precision of the surrogate is reduced from 8 bits to 1–2 bits?",
     "RQ2: Does the quantizer design (per-tensor versus per-channel scale, learned versus min–max step) change accuracy at a given bitwidth?",
     "RQ3: Which width and depth give the best accuracy within a memory budget of a few kilobytes, and does mixed precision (8-bit first or last layer) help?",
     "RQ4: Which input features drive the surrogate's predictions, and do different XAI methods agree?"])
h2("1.4 Contributions")
bul(["We formulate surrogate selection as a budgeted accuracy maximization over precision, quantizer design, architecture and mixed precision (Eq. {e:prob}).",
     "We propose W6A6-32-16-PT-LSQ, a 2,593-parameter, 2.08 KB quantized surrogate with an 8-bit input stage and learned per-tensor step sizes.",
     "We report four ablation studies and OOF5 results on two real datasets (GPU and Intel CPU), without classical or baseline learners.",
     "We provide an analytical Cortex-M4 cost model and a full XAI package (permutation importance, Integrated Gradients, PDP/ICE, SHAP)."])

# ---- 2 SCOPE
h1("2. Research Scope")
p("The scope is restricted to regression surrogates for tabular hardware specifications. Let 𝒟 = 𝒟_{GPU} ∪ 𝒟_{CPU} denote the two datasets. The search space of the surrogate is")
eq("space", "𝒞 = ℬ × 𝒜 × ℋ × Π × Λ,   ℬ ⊂ {1, 2, 3, 4, 6, 8},   Π = {PT, PC},   Λ = {LSQ, MM}")
p("where ℋ contains the hidden-width tuples in Section 4 and 𝒜 the activation bitwidths. The feasible set under the memory budget is")
eq("feas", "𝒞_{B} = { c ∈ 𝒞 : M(c) ≤ B_{mem} }")
p("The input dimension after preprocessing is d_{in} = d_{num} + d_{miss} + d_{cat}, with d_{in} = 63 for the GPU data and 74 for the CPU data.")
eq("din", "d_{in} = d_{num} + d_{miss} + d_{cat}")
bul(["In scope: preprocessing of real specification tables, quantization-aware deep surrogates, OOF5 validation, four ablations, analytical cycle estimation and XAI.",
     "Out of scope: classical machine-learning learners and baseline models (excluded by design), execution of ML-KEM kernels on a board, side-channel analysis, and replacement of NTT arithmetic by neural approximations."])

# ---- 3 RELATED WORK
h1("3. Related Work")
h2("3.1 Lattice cryptography on embedded devices")
p("Alkim et al. {c:newhope} proposed a ring-LWE key exchange that preceded Kyber, and Bos et al. {c:bos} introduced the module-lattice KEM that became ML-KEM {c:fips203}. "
  "Kannwischer et al. {c:pqm4} built the pqm4 framework to test and benchmark candidates on a Cortex-M4 discovery board with 196 KiB of memory, and observed that some candidates exceed the memory of that platform. "
  "Botros et al. {c:botros} reduced the memory use of Kyber on the Cortex-M4, and Alkim et al. {c:alkim20} proposed Cortex-M4 optimizations for ring- and module-LWE schemes. "
  "At the arithmetic level, the NTT follows the Cooley–Tukey decomposition {c:ct}, and optimized transforms have been reported by Seiler {c:seiler}.")
h2("3.2 Neural network quantization")
p("Bengio et al. {c:ste} described the straight-through estimator that makes training with rounding operators possible. Courbariaux et al. {c:bc} trained networks with binary weights, Rastegari et al. {c:xnor} extended this to binary activations, and Li et al. {c:twn} proposed ternary weights. "
  "Zhou et al. {c:dorefa} studied low-bitwidth weights, activations and gradients, and Hubara et al. {c:hubara} gave a general treatment of quantized networks. "
  "Jacob et al. {c:jacob} defined an integer-only inference scheme, while Krishnamoorthi {c:kris} and Nagel et al. {c:nagel} summarized practical quantization choices. "
  "Learned clipping and step sizes were introduced by Choi et al. {c:pact} and Esser et al. {c:lsq}, and Han et al. {c:han} combined quantization with pruning and coding for compression. "
  "Most of this work targets image classifiers; tabular regression surrogates at 1–8 bits are less often examined.")
h2("3.3 TinyML runtimes and hardware-performance surrogates")
p("Lai et al. {c:cmsis} provided CMSIS-NN kernels for Arm Cortex-M CPUs, David et al. {c:tflm} described TensorFlow Lite Micro, and Banbury et al. {c:mlperf} proposed the MLPerf Tiny benchmark. "
  "On the modelling side, Mendis et al. {c:ithemal} predicted basic-block throughput with deep networks, Zhang et al. {c:nnmeter} predicted inference latency across edge devices, and Li et al. {c:hwnas} released a benchmark for hardware-aware architecture search. "
  "Cai et al. {c:proxyless} included latency in the search objective. Our setting differs in that the surrogate predicts a capability indicator from device specifications, and the surrogate is itself constrained to a few kilobytes.")
h2("3.4 Explainability for regression networks")
p("Sundararajan et al. {c:ig} proposed Integrated Gradients, Lundberg and Lee {c:shap} proposed SHAP values, Fisher et al. {c:fisher} formalized permutation-based variable importance, and partial dependence {c:pdp} and individual conditional expectation {c:ice} describe feature effects. "
  "We use all four families because they rely on different assumptions and can be compared.")
h2("3.5 Research gap")
p("The literature above addresses (i) fast lattice kernels, (ii) quantization of vision networks and (iii) hardware-performance prediction, usually separately. To our knowledge, a budgeted comparison of ultra-low-bitwidth tabular surrogates for device screening, with an explicit XAI package and OOF validation, has not been reported in these threads. This motivates the formulation in Section 1.2.")

# ---- 4 METHODOLOGY
h1("4. Methodology")
h2("4.1 Overall workflow")
p("Figure {f:flow} shows the sequence we follow: dataset acquisition, parsing and cleaning, feature construction, fold-wise preprocessing, quantization-aware training of candidate surrogates, four ablation stages, selection of the proposed model, OOF5 validation, cost estimation, XAI, and export.")
fig("flow", "Workflow of the proposed framework from dataset acquisition to export of the integer model.", None, "pipeline.png")
h2("4.2 Dataset acquisition")
p("We use two real CSV files from the Computer Parts dataset {c:kaggle}: All_GPUs.csv (3,406 rows, 34 columns) and Intel_CPUs.csv (2,283 rows, 45 columns). No synthetic data are used. "
  "The GPU target is Texture_Rate (GTexel/s) and the CPU target is TDP (W). Table {t:data} summarizes the processed data.")
tbl("data", "Summary of the real datasets after cleaning.", ["Item", "GPU (All_GPUs.csv)", "CPU (Intel_CPUs.csv)"],
    [["Raw shape (rows × columns)", "3,406 × 34", "2,283 × 45"], ["Usable rows (target > 0)", "2,861", "2,216"], ["Target", "Texture_Rate", "TDP"],
     ["Numeric features", "19", "16"], ["One-hot features", "36", "46"], ["Model input dimension d_{in}", "63", "74"]], [2.4, 2.0, 2.0])
h2("4.3 Dataset preparation")
p("Specification strings such as “1,200 MHz” or “2.60 GHz” are converted to numbers. Let u(v) be the unit factor (GHz → 1000 MHz, GB → 1024 MB, and so on). The parsing operator is")
eq("parse", "π(v) = u(v) · float( first numeric token of v )")
p("Columns with more than 60 % missing values, identifiers and names are removed; date columns are reduced to a year. Columns with at least 5 % missing values receive an indicator, following common imputation practice {c:sklearn}:")
eq("miss", "m_{ij} = 𝟙[ x_{ij} is missing ]")
p("Non-negative numeric columns with sample skewness above 2 are log-transformed:")
eq("skew", "x̃_{ij} = log( 1 + max(x_{ij}, 0) )")
p("Within each training fold, missing values are replaced by the training median, and features are standardized and clipped to [−5, 5] using training statistics only, which avoids leakage {c:stone}:")
eq("std", "z_{ij} = clip( (x̃_{ij} − μ_{j}^{tr}) / σ_{j}^{tr}, −5, 5 )")
p("The target is log-transformed and standardized with training-fold statistics, and predictions are mapped back to the original scale:")
eq("tgt", "ỹ_{i} = ( log(1 + y_{i}) − m_{y} ) / s_{y}")
eq("inv", "ŷ_{i} = max( 0, exp( s_{y} · ỹ̂_{i} + m_{y} ) − 1 )")
p("Categorical columns with at most 40 levels are one-hot encoded (top 10 levels, plus “Other” and “Missing”). Pixel_Rate, Name and Resolution_WxH were dropped from the GPU table, and Processor_Number and Product_Collection from the CPU table.")
h2("4.4 Quantized deep surrogate")
p("The surrogate is a multilayer perceptron whose weights and activations are fake-quantized during training, in the manner of integer-arithmetic-only training {c:jacob}. For b ≥ 3 bits the weight quantizer is symmetric and uniform with step s and q_{max} = 2^{b−1} − 1:")
eq("quant", "Q_{b}(w; s) = s · clip( round(w / s), −q_{max}, q_{max} )")
p("For b = 2 the same expression yields ternary weights {c:twn}, and for b = 1 we use a binary form with a scale given by the mean absolute weight {c:bc}, {c:xnor}:")
eq("bin", "Q_{1}(w) = α · sign(w),    α = mean( |w| )")
p("Because rounding has zero gradient almost everywhere, we use the straight-through estimator {c:ste}:")
eq("ste", "∂ round(u) / ∂u ≈ 1  for  |u| ≤ q_{max}")
p("With learned step sizes (LSQ) {c:lsq}, the step is initialized from the weights and its gradient is rescaled by the layer size:")
eq("lsq0", "s_{0} = 2 · mean(|w|) / √q_{max}")
eq("lsqg", "s ← s·g + sg(s − s·g),    g = 1 / √( N_{w} · q_{max} )")
p("where sg(·) stops the gradient and N_{w} is the number of weights in the layer. The min–max alternative sets s = max|w| / q_{max}. Hidden activations after ReLU use an unsigned a-bit quantizer with a clipping value α_{a}, related to PACT {c:pact}:")
eq("actq", "Q_{a}(u; α_{a}) = ( α_{a} / (2^{a} − 1) ) · clip( round( u (2^{a} − 1) / α_{a} ), 0, 2^{a} − 1 )")
p("The input features pass through a signed 8-bit quantizer in all variants. The forward pass of a surrogate with L layers is")
eq("fwd", "h_{l} = Q_{a}( ReLU( Q_{b_{l}}(W_{l}) h_{l−1} + β_{l} ) ),   l < L;     ŷ = Q_{b_{L}}(W_{L}) h_{L−1} + β_{L}")
p("The mixed-precision variants set b_{1} or b_{L} to 8 bits. The formulation in Eq. {e:fwd} keeps a different weight precision per layer under one set of learned clipping values, which is the structure used in the proposed model and its ablations.")
h2("4.5 Training objective")
p("We minimize the Huber loss {c:huber} on the standardized target with β = 0.5:")
eq("loss", "ℓ(ỹ, ỹ̂) = ½ (ỹ − ỹ̂)² / β  if |ỹ − ỹ̂| < β;    |ỹ − ỹ̂| − ½β  otherwise")
p("Optimization uses AdamW {c:adamw} with a cosine learning-rate schedule, implemented in PyTorch {c:torch}:")
eq("lr", "η_{t} = ½ η_{0} ( 1 + cos( π t / T ) )")
tbl("hyper", "Training and implementation settings.", ["Setting", "Value"],
    [["Optimizer / learning rate / weight decay", "AdamW / 3×10⁻³ / 10⁻⁴"], ["Schedule", "Cosine, T = 150 epochs"], ["Batch size", "128"],
     ["Early stopping", "Patience 30 epochs on a 10 % inner validation split"], ["Loss", "Huber (β = 0.5) on standardized log-target"],
     ["Input quantizer", "Signed 8-bit, clip 5.0"], ["Activation quantizer", "Unsigned a-bit, initial clip 6.0"], ["Seeds", "42 + fold index"]], [3.0, 3.4])
h2("4.6 Embedded cost model")
p("For layer l with n_{l} = i_{l} · o_{l} weights at b_{l} bits, o_{l} outputs, a per-tensor (PT) or per-channel (PC) scale, the memory footprint is")
eq("mem", "M(c) = Σ_{l} [ ⌈ n_{l} b_{l} / 8 ⌉ + 4 o_{l} + 4 s_{l} ] + 4 (L + 1)")
p("with s_{l} = 1 for PT and s_{l} = o_{l} for PC. The number of multiply–accumulates and the estimated cycles are")
eq("mac", "MAC(c) = Σ_{l} i_{l} o_{l}")
eq("cyc", "Ĉ(c) = Σ_{l} [ i_{l} o_{l} κ(b_{l}) + ν o_{l} ],    Ĉ_{fp32} = 3 · MAC(c) + ν Σ_{l} o_{l}")
p("where κ(b) is an assumed cycles-per-MAC value for a Cortex-M4-class core (Table {t:kappa}), loosely informed by CMSIS-NN style kernels {c:cmsis}, and ν = 20 cycles per output neuron covers re-quantization. These constants are our assumptions and have not been measured; Ĉ_{fp32} is a cost reference only, and no floating-point model was trained.")
tbl("kappa", "Assumed cycles per MAC κ(b) used in the analytical cost model.", ["Weight bits", "8, 6, 5", "4", "3", "2", "1"],
    [["κ(b) (cycles/MAC)", "0.75", "0.95", "1.00", "0.60", "0.12"]], [1.6, 1.0, 0.8, 0.8, 0.8, 0.8])
h2("4.7 Ablation design and selection of the proposed model")
p("Four ablations are run in sequence. (A) Bitwidth: (W,A) ∈ {(8,8), (6,6), (4,4), (3,3), (2,4), (2,2), (1,4)} with hidden widths (64, 32), per-channel LSQ. (B) Quantizer design: per-tensor or per-channel scale and learned or min–max step at the best A configuration. "
  "(C) Architecture: hidden widths (16), (32), (32,16), (64,32), (128,64), (64,32,16). (D) Mixed precision: 8-bit first layer, 8-bit last layer, both, or neither. Each stage carries forward the configuration chosen by")
eq("stage", "c_{s}* = argmin_{c ∈ 𝒞_{s}, R²_{log}(c) ≥ R²_{log,max} − δ}  M(c),    δ = 0.002")
p("After the four stages, the proposed model is selected among all evaluated configurations with the budgeted rule that implements Eq. {e:prob} with the memory constraint:")
eq("final", "c* = argmax_{c ∈ 𝒞_{B}, B_{mem} = 2.5 KB}  R²_{OOF}(c)")
p("Equation {e:final} differs from selection by accuracy alone, because a larger model with slightly higher R² is excluded when it exceeds the budget. It differs from Eq. {e:stage}, which is a greedy rule used only to pass a configuration to the next ablation stage. "
  "We note that the 2.5 KB value is a design choice; other budgets would give other selections.")
h2("4.8 Validation protocol")
p("We use K = 5 shuffled folds (seed 42) with cross-validatory assessment {c:stone}, as implemented in scikit-learn {c:sklearn}. For each fold k, the surrogate trained on the other four folds predicts the held-out fold, and the predictions are assembled into an out-of-fold vector:")
eq("folds", "{1, …, N} = ⊔_{k=1}^{K} 𝒯_{k},    K = 5")
eq("oof", "ŷ_{i}^{OOF} = f( x_{i} ; Q(θ^{(−k(i))}) ),    i ∈ 𝒯_{k(i)}")
p("Metrics are computed on the pooled OOF predictions in the original scale, and also on the log scale because the targets are right-skewed:")
eq("r2", "R² = 1 − Σ_{i}(y_{i} − ŷ_{i})² / Σ_{i}(y_{i} − ȳ)²")
eq("rmse", "RMSE = √( (1/N) Σ_{i} (y_{i} − ŷ_{i})² )")
eq("mae", "MAE = (1/N) Σ_{i} |y_{i} − ŷ_{i}|")
eq("mape", "MAPE = (100/N) Σ_{i} |y_{i} − ŷ_{i}| / y_{i}")
eq("r2log", "R²_{log} = 1 − Σ_{i}(log(1+y_{i}) − log(1+ŷ_{i}))² / Σ_{i}(log(1+y_{i}) − mean(log(1+y)))²")
eq("foldstat", "m̄ = (1/K) Σ_{k} m_{k},    s_{m} = √( (1/(K−1)) Σ_{k} (m_{k} − m̄)² )")
p("Preprocessing statistics are estimated on each training fold only. The same seeds are used for every configuration so that configurations are compared on identical splits.")
h2("4.9 Explainability methods")
p("Permutation importance {c:fisher} is the increase of the standardized MSE when feature j of a held-out fold is shuffled:")
eq("perm", "PI_{j} = (1/R) Σ_{r=1}^{R} [ MSE( X^{(π_{r}, j)} ) − MSE( X ) ]")
p("Integrated Gradients {c:ig} attribute the prediction to features along a straight path from a zero (mean-feature) baseline x′:")
eq("igeq", "IG_{j}(x) = (x_{j} − x′_{j}) ∫_{0}^{1} ∂f( x′ + t (x − x′) ) / ∂x_{j} dt")
p("We approximate the integral with 32 midpoint steps; gradients pass through the quantizers via the estimator in Eq. {e:ste}. Partial dependence {c:pdp}, individual conditional expectation {c:ice} and Shapley values {c:shap} are")
eq("pdpeq", "PD_{j}(v) = (1/N) Σ_{i} f( v, x_{i,−j} ),    ICE_{i,j}(v) = f( v, x_{i,−j} )")
eq("shapeq", "φ_{j} = Σ_{S ⊆ F∖{j}} [ |S|! (|F|−|S|−1)! / |F|! ] ( f(S ∪ {j}) − f(S) )")
p("Equation {e:shapeq} is estimated with a kernel-based approximation on 150 samples and a 50-sample background, when the SHAP package is available.")

# ---- 5 RESULTS
h1("5. Results and Analysis")
h2("5.1 Overview of tables and figures")
p("Table {t:data} describes the data. Tables {t:gA}–{t:gD} report the four ablations on the GPU data, and Tables {t:cA}–{t:cD} report them on the CPU data. Table {t:prop} gives the proposed models, Table {t:cost} the estimated embedded cost and Table {t:fold} the per-fold GPU metrics. "
  "Table {t:xai} lists the highest-ranked features. Figures {f:eda1}–{f:eda4} describe the GPU data, Figures {f:aA}–{f:aD} show the GPU ablations, Figures {f:par} and {f:cyc} show cost trade-offs, Figures {f:pva}–{f:lat} validate the proposed model, "
  "and Figures {f:perm}–{f:shap} are XAI plots. Figures {f:cA}–{f:cig} repeat the main results for the CPU data.")

def stage_table(ds, stage, key, cap):
    rows = []
    for name, r2l, r2, rm in STAGES[ds][stage]:
        c = cost(name, D_IN[ds]); rows.append([name, f"{r2l:.4f}", f"{r2:.4f}", f"{rm:.3f}", f"{c['kb']:.2f}", f"{c['cyc']:.0f}"])
    tbl(key, cap, ["Configuration", "R²(log)", "R²", "RMSE", "Memory (KB)", "Est. cycles"], rows, [2.2, .75, .7, .7, .85, .85])

h2("5.2 Data characteristics (GPU)")
fig("eda1", "Distribution of the GPU target Texture_Rate on the raw and log scales.", "GPU", "eda_target_distribution.png")
fig("eda2", "Share of missing values for the numeric GPU features.", "GPU", "eda_missingness.png")
fig("eda3", "Correlation heatmap of the 20 numeric GPU features most correlated with the log-target.", "GPU", "eda_correlation_heatmap.png")
fig("eda4", "Absolute correlation of the leading GPU features with the log-target.", "GPU", "eda_feature_target_correlation.png")
p("Figure {f:eda1} shows a right-skewed target, which motivates the log transform in Eq. {e:tgt} and the use of R²_{log} alongside R². Figure {f:eda2} shows the share of missing values, and indicator columns (Eq. {e:miss}) were added for features with at least 5 % missing. "
  "Figures {f:eda3} and {f:eda4} show that several specification features are strongly correlated with each other and with the target. This is expected because Texture_Rate is, on paper, the product of texture-unit count and core clock; "
  "high accuracy on this target should therefore be read with that structure in mind (Section 6).")
h2("5.3 Ablation A: bitwidth")
stage_table("GPU", "A_bitwidth", "gA", "Ablation A on the GPU data: weight/activation bitwidth (OOF5).")
fig("aA", "Ablation A (GPU): OOF5 R²(log) with fold standard deviation (left) and memory (right) for each bitwidth.", "GPU", "ablation_A_bitwidth.png")
p("Table {t:gA} and Figure {f:aA} address RQ1. R²_{log} decreases gradually from 0.9914 (W8A8) to 0.9892 (W4A4) and 0.9856 (W3A3), and then more steeply to 0.9684 for W2A2. The W2A4 setting (0.9814) is better than W2A2, which suggests that activation precision matters at 2-bit weights. "
  "The binary-weight W1A4 model reaches 0.9753 with 1.52 KB. On the original scale, W6A6 (R² = 0.9803) is slightly higher than W8A8 (0.9770); this difference is small and within what fold variation could produce, so we do not read it as a systematic advantage. "
  "Under the assumed κ(b), 3–4-bit models need more cycles than 8-bit ones because of unpacking overhead, so memory savings and cycle savings do not coincide in this model.")
h2("5.4 Ablation B: quantizer design")
stage_table("GPU", "B_quantizer", "gB", "Ablation B on the GPU data: scale granularity and step-size rule at W6A6.")
fig("aB", "Ablation B (GPU): accuracy and memory for the four quantizer designs.", "GPU", "ablation_B_quantizer.png")
p("Table {t:gB} and Figure {f:aB} address RQ2. The four designs differ by at most 0.0006 in R²_{log} (0.9902–0.9908). Per-tensor LSQ gives 0.9908 with 4.88 KB, compared with 0.9907 for per-channel LSQ at 5.25 KB. "
  "Given the fold variation, we regard the accuracy of the four designs as comparable here, and the per-tensor scale is preferable for memory.")
h2("5.5 Ablation C: architecture")
stage_table("GPU", "C_architecture", "gC", "Ablation C on the GPU data: hidden widths at W6A6 with per-tensor LSQ.")
fig("aC", "Ablation C (GPU): accuracy and memory for six architectures.", "GPU", "ablation_C_architecture.png")
p("Table {t:gC} and Figure {f:aC} address the first part of RQ3. The 128-64 network has the highest R²_{log} (0.9918) but needs 12.73 KB. The 64-32-16 network has the highest R² (0.9827, RMSE 11.93) at 5.32 KB. "
  "The 32-16 network reaches R² = 0.9810 and RMSE 12.52 with 2.08 KB, i.e. within 0.0017 of the 64-32-16 R² at 39 % of its memory. A single hidden layer of 16 units (0.84 KB) retains R²_{log} = 0.9888.")
h2("5.6 Ablation D: mixed precision")
stage_table("GPU", "D_mixed_precision", "gD", "Ablation D on the GPU data: 8-bit first and/or last layer (hidden width 32).")
fig("aD", "Ablation D (GPU): accuracy and memory for mixed-precision settings.", "GPU", "ablation_D_mixed_precision.png")
p("Table {t:gD} and Figure {f:aD} address the second part of RQ3. Raising the first or last layer to 8 bits changed R²_{log} by at most 0.0004 and did not improve R² consistently (0.9711–0.9766 versus 0.9752 for the uniform 6-bit model). Using 8 bits in both layers lowered R² to 0.9605. "
  "In our runs, mixed precision therefore added memory without a clear benefit.")
h2("5.7 Selection and accuracy–cost trade-off")
fig("par", "Accuracy versus memory (left) and versus estimated cycles (right) for all evaluated configurations; the star marks the proposed model.", "GPU", "pareto_accuracy_vs_cost.png")
fig("cyc", "Estimated Cortex-M4 cycles per inference for the bitwidth ablation, the proposed model and the floating-point cost reference.", "GPU", "estimated_cycles.png")
p("Figure {f:par} shows the evaluated configurations. Under the 2.5 KB budget of Eq. {e:final}, the 32-16 network at W6A6 has the highest OOF5 R². Models with higher R² (for example the 64-32-16 network) exceed the budget. "
  "Figure {f:cyc} compares estimated cycles. For the proposed model Ĉ = 2,888 cycles against a floating-point cost reference of 8,612 cycles (a factor of about 3.0), and the 64-32 W8A8 model needs about 6,500 cycles under the same assumptions (Table {t:cost}). These values are analytical and should be checked on a board.")
tbl("cost", "Estimated embedded cost of the proposed models and the GPU bitwidth ablation (analytical model, d_{in} per Table {t:data}).",
    ["Model", "Params", "MACs", "Memory (KB)", "Est. cycles", "FP32 cost ref."],
    [[n, "—", str(cost(n, 63)["macs"]), f"{cost(n,63)['kb']:.2f}", f"{cost(n,63)['cyc']:.0f}", f"{cost(n,63)['fp32']:.0f}"] for n in
     ["W6A6|32-16|PT-LSQ|f_h_ (GPU proposed)", "W8A8|64-32|PC-LSQ|f_h_", "W4A4|64-32|PC-LSQ|f_h_", "W2A2|64-32|PC-LSQ|f_h_", "W1A4|64-32|PC-LSQ|f_h_"]
     ] if False else
    [["GPU proposed W6A6|32-16|PT-LSQ", "2,593", str(cost("W6A6|32-16|PT-LSQ|f_h_", 63)["macs"]), f"{cost('W6A6|32-16|PT-LSQ|f_h_',63)['kb']:.2f}", f"{cost('W6A6|32-16|PT-LSQ|f_h_',63)['cyc']:.0f}", f"{cost('W6A6|32-16|PT-LSQ|f_h_',63)['fp32']:.0f}"],
     ["CPU selected W8A8|32|PT-MM", "2,433", str(cost("W8A8|32|PT-MM|f_h_", 74)["macs"]), f"{cost('W8A8|32|PT-MM|f_h_',74)['kb']:.2f}", f"{cost('W8A8|32|PT-MM|f_h_',74)['cyc']:.0f}", f"{cost('W8A8|32|PT-MM|f_h_',74)['fp32']:.0f}"]] +
    [[f"GPU {n.split('|')[0]} (64-32, PC-LSQ)", f"{cost(n, 63)['params']:,}", str(cost(n, 63)["macs"]), f"{cost(n,63)['kb']:.2f}", f"{cost(n,63)['cyc']:.0f}", f"{cost(n,63)['fp32']:.0f}"] for n in
     ["W8A8|64-32|PC-LSQ|f_h_", "W4A4|64-32|PC-LSQ|f_h_", "W2A2|64-32|PC-LSQ|f_h_", "W1A4|64-32|PC-LSQ|f_h_"]],
    [2.3, .7, .7, .9, .9, .9])
h2("5.8 Proposed model: OOF5 validation (GPU)")
tbl("prop", "OOF5 performance and footprint of the proposed models.", ["Dataset (target)", "Model", "R²", "R²(log)", "RMSE", "MAE", "MAPE (%)", "KB"],
    [["GPU (Texture_Rate)", "W6A6|32-16|PT-LSQ", "0.9810", "0.9907", "12.522", "4.461", "7.72", "2.08"],
     ["CPU (TDP)", "W8A8|32|PT-MM", "0.9471", "0.9421", "10.308", "6.786", "29.31", "2.49"]], [1.3, 1.5, .55, .6, .6, .55, .65, .45])
p("Table {t:prop} gives the headline results. For the GPU data, the proposed W6A6-32-16-PT-LSQ network reaches R² = 0.9810, RMSE = 12.52 and MAPE = 7.7 % with 2,593 parameters. The figures below validate this model.")
fig("pva", "OOF5 predicted versus actual Texture_Rate for the proposed model (log axes).", "GPU", "proposed_oof_pred_vs_actual.png")
fig("res", "Distribution of OOF5 residuals (left) and residuals versus predicted value (right).", "GPU", "proposed_residuals.png")
fig("fold", "Per-fold R²(log), RMSE and MAPE of the proposed model.", "GPU", "proposed_per_fold_metrics.png")
fig("dec", "Mean absolute percentage error by target decile.", "GPU", "proposed_error_by_decile.png")
fig("lc", "Training and validation Huber loss of the proposed model in the five folds.", "GPU", "proposed_learning_curves.png")
fig("wl", "Usage of integer weight levels per layer in the exported proposed model.", "GPU", "proposed_weight_levels.png")
fig("lat", "Distribution of latent (full-precision) weights per layer before quantization.", "GPU", "proposed_latent_weight_hist.png")
p("Figure {f:pva} shows OOF5 predictions close to the diagonal across the range of the target. Figure {f:res} summarizes the residuals; the spread on the original scale grows with the magnitude of the target, which is consistent with training on a log-transformed target. "
  "Figure {f:fold} and Table {t:fold} show fold-wise metrics. R²_{log} is stable across folds (0.9895–0.9923), while R² on the original scale ranges from 0.9562 to 0.9930; the lowest fold (fold 4, RMSE 18.80) may reflect a few high-valued devices, which we did not investigate further. Figure {f:dec} reports the error by target decile, which helps to see where the surrogate is less reliable. "
  "Figure {f:lc} shows training and validation loss of the five fold models. Figure {f:wl} shows how the 6-bit integer levels are used, and Figure {f:lat} shows the latent weights before quantization. "
  "The exported integer weights reproduced the fake-quantized network output exactly in our consistency check (maximum absolute difference 0).")
FOLD = "GPU/proposed_fold_metrics.csv"
B.append(("foldtable", "fold", "Per-fold OOF5 metrics of the proposed GPU model.", FOLD))
h2("5.9 Explainability (GPU)")
fig("perm", "Permutation importance of the leading GPU features on held-out folds (mean ± std across folds).", "GPU", "xai_permutation_importance.png")
fig("igb", "Global importance by mean absolute Integrated Gradients.", "GPU", "xai_integrated_gradients_bar.png")
fig("igs", "Integrated Gradients attributions per sample for the ten leading features (beeswarm-style).", "GPU", "xai_integrated_gradients_beeswarm.png")
fig("agr", "Agreement between permutation importance and mean absolute Integrated Gradients.", "GPU", "xai_method_agreement.png")
fig("pdp", "Partial dependence (red) and ICE curves (grey) for the leading numeric features.", "GPU", "xai_pdp_ice.png")
fig("shap", "SHAP summary plot of the proposed model (kernel estimator).", "GPU", "xai_shap_summary.png")
B.append(("xaitable", "xai", "Leading features by permutation importance and Integrated Gradients (GPU).", "GPU/xai_importances.csv"))
B.append(("xaitext", "GPU/xai_importances.csv"))
p("Figures {f:perm}–{f:shap} and Table {t:xai} address RQ4. Permutation importance (Eq. {e:perm}) measures the loss of accuracy when a feature is shuffled, Integrated Gradients (Eq. {e:igeq}) describe local attributions that we average over samples, and PDP/ICE and SHAP show direction and shape of effects. "
  "Permutation importance is dominated by TMUs (0.729 ± 0.040), followed by Memory_Bandwidth (0.146) and Memory_Bus (0.049), and Integrated Gradients give the same top three, with Core_Speed fourth on both measures. This is consistent with the near-product structure of Texture_Rate noted in Section 5.2, and suggests the surrogate has largely learned that relationship. Figure {f:agr} compares the first two rankings; where points lie close to a monotone trend, the methods agree. Because several GPU features are correlated (Figure {f:eda3}), importance can be shared among them, and we therefore read the rankings as indicative.")
h2("5.10 CPU dataset")
stage_table("CPU", "A_bitwidth", "cA", "Ablation A on the CPU data: bitwidth (OOF5).")
stage_table("CPU", "B_quantizer", "cB", "Ablation B on the CPU data: quantizer design at W8A8.")
stage_table("CPU", "C_architecture", "cC", "Ablation C on the CPU data: hidden widths at W8A8 with per-tensor min–max.")
stage_table("CPU", "D_mixed_precision", "cD", "Ablation D on the CPU data: mixed precision (64-32).")
fig("cA", "Ablation A (CPU): accuracy and memory for each bitwidth.", "CPU", "ablation_A_bitwidth.png")
fig("cC", "Ablation C (CPU): accuracy and memory for six architectures.", "CPU", "ablation_C_architecture.png")
fig("cpar", "Accuracy versus memory and estimated cycles for CPU configurations.", "CPU", "pareto_accuracy_vs_cost.png")
fig("cpva", "OOF5 predicted versus actual TDP for the selected CPU model.", "CPU", "proposed_oof_pred_vs_actual.png")
fig("cperm", "Permutation importance for the selected CPU model.", "CPU", "xai_permutation_importance.png")
fig("cig", "Mean absolute Integrated Gradients for the selected CPU model.", "CPU", "xai_integrated_gradients_bar.png")
p("Tables {t:cA}–{t:cD} and Figures {f:cA}–{f:cig} repeat the analysis for TDP. R²_{log} falls from 0.9542 (W8A8) to 0.9274 (W1A4) as precision decreases, a steeper loss than on the GPU data, and the 8-bit model was carried into the later stages because W6A6 was 0.0034 lower, "
  "which is outside the tolerance δ of Eq. {e:stage}. Quantizer designs differ by at most 0.0042 in R²_{log}, with per-tensor min–max highest (0.9556). Architecture matters more: the 128-64 network reaches R² = 0.9579 at 18.09 KB, while the 32 network reaches 0.9471 at 2.49 KB. "
  "Ablation D shows identical values because all layers are already 8-bit, so the first/last-layer override changes nothing; we include it for completeness. Under the 2.5 KB budget the selected CPU model is W8A8|32|PT-MM (R² = 0.9471, MAPE 29.3 %). "
  "The relatively high MAPE suggests that TDP is harder to predict for low-power parts; the model should be used for coarse screening on this target. Because lower-bit variants were not carried through stages B–D for the CPU data, the CPU study is less complete than the GPU study.")
h2("5.11 Discussion")
p("Across both datasets, accuracy decreased gently down to 4-bit weights and then more clearly at 2 bits, so memory could be reduced by about a factor of four relative to 8-bit with a small loss on the GPU data (RQ1). "
  "Quantizer design had a smaller effect than width and depth (RQ2, RQ3). Within a 2.5 KB budget, the W6A6 32-16 network was the most accurate candidate we evaluated on the GPU data. "
  "The estimated cycle count of about 2.9 × 10³ per inference is small compared with the cost of lattice kernels reported on this class of device {c:pqm4}, so the surrogate would be a minor overhead if used for on-device screening; this remains to be confirmed by measurement.")

# ---- 6 CONCLUSION
h1("6. Conclusion")
p("We examined a deep learning surrogate for screening hardware against lattice workloads and proposed W6A6-32-16-PT-LSQ, a 2.08 KB quantized network. Each research question is addressed as follows.")
bul(["RQ1 (precision): accuracy declined slowly from 8 to 4 bits and more clearly at 2 bits; W1A4 retained R²_{log} = 0.9753 on the GPU data (Table {t:gA}).",
     "RQ2 (quantizer design): the four designs were within 0.0006 R²_{log} on the GPU data, so per-tensor scaling is a reasonable choice for memory (Table {t:gB}).",
     "RQ3 (architecture and mixed precision): the 32-16 network gave R² = 0.9810 within 2.08 KB; 8-bit first/last layers gave no consistent benefit (Tables {t:gC}, {t:gD}).",
     "RQ4 (explainability): permutation importance, Integrated Gradients, PDP/ICE and SHAP were produced and can be compared (Figures {f:perm}–{f:shap}); we interpret them with the correlation structure in mind."])
h2("Threats to validity")
p("Internal: hyperparameters were not tuned per configuration, and the differences between several configurations are of the order of the fold variation. The greedy ablation order may affect which configurations are explored, and the 2.5 KB budget affects the final choice. "
  "Construct: the targets are specification-derived indicators, and Texture_Rate is close to a product of two specification columns, so high R² is partly expected; the link from these indicators to ML-KEM timing is a modelling assumption (Eq. {e:ratio}). "
  "External: the data are product-catalog entries rather than measured benchmarks, and may contain inconsistencies. Conclusion: cycle counts are analytical, with assumed κ(b) and ν.")
h2("Limitations")
p("We did not run ML-KEM on a microcontroller, did not measure cycles or energy, and did not compare with classical or baseline learners, as these were excluded by design. Only two tables were studied, and the CPU ablation does not carry lower-bit variants through every stage.")
h2("Future work")
p("Future work includes measuring the exported integer model on Cortex-M targets with CMSIS-NN style kernels {c:cmsis}, validating Eq. {e:ratio} against measured ML-KEM timings from pqm4 {c:pqm4}, using measured benchmark data as targets, exploring pruning and coding {c:han}, and repeating the study with more seeds to quantify configuration differences.")
B.append(("refs",))

# ----------------------------------------------------------------------------- BUILD
ORDER, EQN, TBN, FGN = [], {}, {}, {}
def scan():
    for b in B:
        t = b[0]; strs = []
        if t in ("h1", "h2", "p"): strs = [b[1]]
        elif t == "bul": strs = b[1]
        elif t == "tbl": strs = [b[2]]
        elif t == "fig": strs = [b[2]]
        for s in strs:
            for m in re.finditer(r"\{c:([a-z0-9_,]+)\}", s):
                for k in m.group(1).split(","):
                    if k not in ORDER: ORDER.append(k)
        if t == "eq": EQN[b[1]] = len(EQN) + 1
        if t == "tbl": TBN[b[1]] = len(TBN) + 1
        if t in ("foldtable", "xaitable"): TBN[b[1]] = len(TBN) + 1
        if t == "fig": FGN[b[1]] = len(FGN) + 1
scan()
# make sure every table is numbered by position of first block (foldtable/xaitable appear in order)
CIT = {k: i + 1 for i, k in enumerate(ORDER)}
unused = [k for k in R if k not in CIT]
assert not unused, f"Unused references: {unused}"

def resolve(s):
    s = re.sub(r"\{c:([a-z0-9_,]+)\}", lambda m: ", ".join(f"[{CIT[k]}]" for k in m.group(1).split(",")), s)
    s = re.sub(r"\{e:(\w+)\}", lambda m: f"({EQN[m.group(1)]})", s)
    s = re.sub(r"\{t:(\w+)\}", lambda m: f"{TBN[m.group(1)]}", s)
    s = re.sub(r"\{f:(\w+)\}", lambda m: f"{FGN[m.group(1)]}", s)
    return s

doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Inches(8.5), Inches(11)
for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"): setattr(sec, m, Inches(1))
st = doc.styles["Normal"]; st.font.name = FONT; st.font.size = Pt(11)
st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
for hn, sz in (("Heading 1", 12), ("Heading 2", 11)):
    s = doc.styles[hn]; s.font.name = FONT; s.font.size = Pt(sz); s.font.bold = True; s.font.italic = (hn == "Heading 2")
    s.font.color.rgb = RGBColor(0, 0, 0); s.element.rPr.rFonts.set(qn("w:eastAsia"), FONT); s.element.rPr.rFonts.set(qn("w:ascii"), FONT); s.element.rPr.rFonts.set(qn("w:hAnsi"), FONT)
    rf = s.element.rPr.rFonts
    for a in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]
    s.paragraph_format.space_before = Pt(10); s.paragraph_format.space_after = Pt(4); s.paragraph_format.keep_with_next = True

TOK = re.compile(r"(_\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}|\^\{[^{}]*\})")
def runs(par, text, size=11, bold=False, italic=False, font=FONT):
    for part in TOK.split(text):
        if not part: continue
        sub, sup = part.startswith("_{"), part.startswith("^{")
        t = part[2:-1] if (sub or sup) else part
        r = par.add_run(t); r.font.name = font; r.font.size = Pt(size); r.bold = bold; r.italic = italic
        r._element.rPr.rFonts.set(qn("w:eastAsia"), font)
        if sub: r.font.subscript = True
        if sup: r.font.superscript = True

def para(text, align=WD_ALIGN_PARAGRAPH.JUSTIFY, size=11, bold=False, italic=False, style=None, after=6, keep=False):
    q = doc.add_paragraph(style=style); q.alignment = align
    q.paragraph_format.line_spacing = LINE; q.paragraph_format.space_after = Pt(after); q.paragraph_format.keep_with_next = keep
    runs(q, resolve(text), size, bold, italic); return q

def no_borders(t):
    tblPr = t._tbl.tblPr; b = OxmlElement("w:tblBorders")
    for e in ("top", "left", "bottom", "right", "insideH", "insideV"):
        x = OxmlElement(f"w:{e}"); x.set(qn("w:val"), "nil"); b.append(x)
    tblPr.append(b)

def shade(cell, color="D9D9D9"):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd")
    sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), color); tcPr.append(sh)

def set_w(cell, w): cell.width = Inches(w)

def add_table(head, rows, widths):
    t = doc.add_table(rows=1, cols=len(head)); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    widths = widths or [6.5 / len(head)] * len(head)
    for i, h in enumerate(head):
        c = t.rows[0].cells[i]; c.text = ""; runs(c.paragraphs[0], resolve(h), 10, bold=True); shade(c); set_w(c, widths[i])
        c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in rows:
        cells = t.add_row().cells
        for i, v in enumerate(r):
            cells[i].text = ""; runs(cells[i].paragraphs[0], resolve(str(v)), 10); set_w(cells[i], widths[i])
            cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT if i == 0 else WD_ALIGN_PARAGRAPH.CENTER
    for row in t.rows:
        for c in row.cells:
            for pp in c.paragraphs: pp.paragraph_format.space_after = Pt(1); pp.paragraph_format.space_before = Pt(1)
    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(4)

def caption_table(key, cap):
    q = para(f"Table {TBN[key]}. {cap}", WD_ALIGN_PARAGRAPH.CENTER, 11, bold=False, after=3, keep=True)
    q.runs[0].bold = False

def fig_caption(key, cap):
    para(f"Fig. {FGN[key]}. {cap}", WD_ALIGN_PARAGRAPH.CENTER, 11, after=8)

# ---- fallback figure generators
def short(n): return n.split("|")[0] + "|" + n.split("|")[1] if n.count("|") >= 3 else n
def fb_ablation(ds, stage, path):
    rows = STAGES[ds][stage]; names = [short(r[0]) + "|" + r[0].split("|")[2] + ("|" + r[0].split("|")[3] if stage == "D_mixed_precision" else "") for r in rows]
    fig_, ax = plt.subplots(1, 2, figsize=(10, 0.45 * len(rows) + 2))
    ax[0].barh(names, [r[1] for r in rows], color="#4C72B0"); lo = min(r[1] for r in rows); ax[0].set_xlim(max(0, lo - .02), 1.0)
    ax[0].set_xlabel("OOF5 R² (log)"); ax[0].set_title(f"Ablation {stage[0]}: accuracy")
    ax[1].barh(names, [cost(r[0], D_IN[ds])["kb"] for r in rows], color="#DD8452"); ax[1].set_yticklabels([]); ax[1].set_xlabel("memory (KB)")
    for a in ax: a.grid(alpha=.3)
    fig_.savefig(path, dpi=200, bbox_inches="tight"); plt.close(fig_)
def fb_pareto(ds, path):
    seen = {}
    for st in STAGES[ds].values():
        for r in st: seen[r[0]] = r
    fig_, ax = plt.subplots(1, 2, figsize=(11, 4.4)); prop = "W6A6|32-16|PT-LSQ|f_h_" if ds == "GPU" else "W8A8|32|PT-MM|f_h_"
    for k, key in enumerate(("kb", "cyc")):
        for n, r in seen.items():
            c = cost(n, D_IN[ds]); ax[k].scatter(c[key], r[1], s=35, c="#4C72B0")
        c = cost(prop, D_IN[ds]); ax[k].scatter(c[key], seen[prop][1], s=300, marker="*", c="red", zorder=5, label="proposed")
        ax[k].set_xscale("log"); ax[k].set_ylabel("OOF5 R² (log)"); ax[k].legend(); ax[k].grid(alpha=.3)
        ax[k].set_xlabel("memory (KB)" if key == "kb" else "est. cycles / inference")
    fig_.savefig(path, dpi=200, bbox_inches="tight"); plt.close(fig_)
def fb_cycles(ds, path):
    A = STAGES[ds]["A_bitwidth"]; prop = "W6A6|32-16|PT-LSQ|f_h_" if ds == "GPU" else "W8A8|32|PT-MM|f_h_"
    labs = [r[0].split("|")[0] for r in A] + ["PROPOSED"]; cy = [cost(r[0], D_IN[ds])["cyc"] for r in A] + [cost(prop, D_IN[ds])["cyc"]]
    fig_, ax = plt.subplots(figsize=(9, 4)); ax.bar(labs, cy, color=["#4C72B0"] * len(A) + ["#C44E52"])
    ref = cost(prop, D_IN[ds])["fp32"]; ax.axhline(ref, ls="--", c="k", label=f"FP32 cost reference: {ref:,.0f}"); ax.set_yscale("log"); ax.legend()
    ax.set_ylabel("est. cycles / inference"); fig_.savefig(path, dpi=200, bbox_inches="tight"); plt.close(fig_)
def fb_pipeline(path):
    steps = ["Real CSV files\n(GPU, CPU)", "Parse units,\nclean, encode", "Fold-wise\nimpute / scale", "QAT of quantized\nsurrogates", "Ablations A–D\n(bits, quantizer,\narchitecture, mixed)",
             "Budgeted selection\n(proposed model)", "OOF5 validation\n+ cost model", "XAI: PI, IG,\nPDP/ICE, SHAP", "Integer export\n+ consistency check"]
    fig_, ax = plt.subplots(figsize=(11, 3.4)); ax.axis("off")
    for i, s in enumerate(steps):
        r, c = divmod(i, 5) if i < 5 else (1, i - 5 + 0.5)
        x, y = c * 2.1 + 0.1, 1.5 - r * 1.5
        ax.text(x + .9, y + .4, s, ha="center", va="center", fontsize=8.5, bbox=dict(boxstyle="round,pad=.4", fc="#E8EEF7", ec="#4C72B0"))
    for i in range(4): ax.annotate("", xy=((i + 1) * 2.1 + .1 + .1, 1.9), xytext=(i * 2.1 + 1.75 + .1, 1.9), arrowprops=dict(arrowstyle="->"))
    ax.annotate("", xy=(0.5 * 2.1 + 1.0, 0.4 + .45), xytext=(4 * 2.1 + .9, 1.9 - .45), arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"))
    for i in range(3): ax.annotate("", xy=((i + 1.5) * 2.1 + .1 + .1, .4), xytext=((i + .5) * 2.1 + 1.75 + .1, .4), arrowprops=dict(arrowstyle="->"))
    ax.set_xlim(0, 10.8); ax.set_ylim(-.2, 2.5); fig_.savefig(path, dpi=200, bbox_inches="tight"); plt.close(fig_)

def get_fig(ds, fname):
    if fname == "pipeline.png":
        pth = TMP / "pipeline.png"; fb_pipeline(pth); return pth
    pth = OUT / ds / "figures" / fname
    if pth.exists(): return pth
    pth = TMP / f"{ds}_{fname}"
    m = re.match(r"ablation_([A-D]_\w+)\.png", fname)
    if m: fb_ablation(ds, m.group(1), pth); return pth
    if fname == "pareto_accuracy_vs_cost.png": fb_pareto(ds, pth); return pth
    if fname == "estimated_cycles.png": fb_cycles(ds, pth); return pth
    return None

def add_fig(ds, fname):
    pth = get_fig(ds, fname); q = doc.add_paragraph(); q.alignment = WD_ALIGN_PARAGRAPH.CENTER
    q.paragraph_format.keep_with_next = True; q.paragraph_format.space_after = Pt(2)
    if pth: q.add_run().add_picture(str(pth), width=Inches(FIG_W))
    else:
        t = doc.add_table(rows=1, cols=1); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        c = t.rows[0].cells[0]; c.width = Inches(FIG_W); c.text = ""; runs(c.paragraphs[0], f"[Insert {ds}/figures/{fname} — generated by the pipeline]", 10, italic=True)
        c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER; t.rows[0].height = Inches(2.4)

def add_equation(key, expr):
    t = doc.add_table(rows=1, cols=3); no_borders(t); t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    w = [0.45, 5.6, 0.45]
    for i, c in enumerate(t.rows[0].cells): set_w(c, w[i]); t.columns[i].width = Inches(w[i])
    c = t.rows[0].cells[1]; c.text = ""; c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER; runs(c.paragraphs[0], expr, 11, italic=False, font="Cambria Math")
    n = t.rows[0].cells[2]; n.text = ""; n.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT; runs(n.paragraphs[0], f"({EQN[key]})", 11)
    for cc in t.rows[0].cells:
        for pp in cc.paragraphs: pp.paragraph_format.space_after = Pt(2); pp.paragraph_format.space_before = Pt(2)

def read_csv(rel):
    f = OUT / rel
    return pd.read_csv(f) if f.exists() else None

# ---- title block
q = doc.add_paragraph(); q.alignment = WD_ALIGN_PARAGRAPH.CENTER; runs(q, TITLE, 14, bold=True); q.paragraph_format.space_after = Pt(6)
q = doc.add_paragraph(); q.alignment = WD_ALIGN_PARAGRAPH.CENTER; runs(q, "[Author name(s)] · [Affiliation] · [Corresponding e-mail]", 11, italic=True); q.paragraph_format.space_after = Pt(8)
q = doc.add_paragraph(); q.alignment = WD_ALIGN_PARAGRAPH.CENTER; runs(q, "Abstract", 12, bold=True); q.paragraph_format.space_after = Pt(2)
para(ABSTRACT, after=4)
q = doc.add_paragraph(); q.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY; runs(q, "Keywords: ", 11, bold=True); runs(q, KEYWORDS, 11, italic=True); q.paragraph_format.space_after = Pt(6)

for b in B:
    t = b[0]
    if t == "h1": doc.add_heading(b[1], 1)
    elif t == "h2": doc.add_heading(b[1], 2)
    elif t == "p": para(b[1])
    elif t == "bul":
        for it in b[1]: para(it, style="List Bullet", after=2)
    elif t == "eq": add_equation(b[1], b[2])
    elif t == "tbl": caption_table(b[1], b[2]); add_table(b[3], b[4], b[5])
    elif t == "fig": add_fig(b[3], b[4]); fig_caption(b[1], b[2])
    elif t == "foldtable":
        caption_table(b[1], b[2]); df = read_csv("GPU/proposed_fold_metrics.csv")
        if df is None:
            add_table(["Fold", "R²", "R²(log)", "RMSE", "MAE", "MAPE (%)"], [["—", "(populated from proposed_fold_metrics.csv)", "", "", "", ""]], None)
        else:
            rows = [[str(i + 1)] + [f"{r[c]:.4f}" if c.startswith("R2") else f"{r[c]:.3f}" for c in ["R2", "R2_log", "RMSE", "MAE", "MAPE"]] for i, r in df.iterrows()]
            rows.append(["Mean ± SD"] + [f"{df[c].mean():.4f} ± {df[c].std():.4f}" if c.startswith("R2") else f"{df[c].mean():.3f} ± {df[c].std():.3f}" for c in ["R2", "R2_log", "RMSE", "MAE", "MAPE"]])
            add_table(["Fold", "R²", "R²(log)", "RMSE", "MAE", "MAPE (%)"], rows, [1.0, 1.1, 1.1, 1.1, 1.1, 1.1])
    elif t == "xaitable":
        caption_table(b[1], b[2]); df = read_csv("GPU/xai_importances.csv")
        if df is None:
            add_table(["Rank", "Permutation importance", "Mean |IG|"], [["—", "(populated from xai_importances.csv)", ""]], None)
        else:
            a = df.sort_values("perm_importance", ascending=False).head(10).reset_index(drop=True)
            g = df.sort_values("mean_abs_IG", ascending=False).head(10).reset_index(drop=True)
            add_table(["Rank", "Feature (permutation)", "PI", "Feature (IG)", "Mean |IG|"],
                      [[i + 1, a.feature[i], f"{a.perm_importance[i]:.4f}", g.feature[i], f"{g.mean_abs_IG[i]:.4f}"] for i in range(len(a))], [.5, 2.0, .8, 2.0, .9])
    elif t == "xaitext":
        df = read_csv("GPU/xai_importances.csv")
        if df is None:
            para("[The ranking sentences of this subsection are generated from xai_importances.csv when the outputs folder is available.]", italic=True)
        else:
            a = list(df.sort_values("perm_importance", ascending=False).feature[:3]); g = list(df.sort_values("mean_abs_IG", ascending=False).feature[:3])
            common = sorted(set(a) & set(g))
            para(f"In our run, the three features with the highest permutation importance were {', '.join(a)}, and the three with the highest mean absolute Integrated Gradients were {', '.join(g)}. "
                 + (f"The two rankings share {', '.join(common)} among their leading features." if common else "The two top-3 lists do not overlap, so we treat the rankings with caution."))
    elif t == "refs":
        doc.add_heading("References", 1)
        for k in ORDER:
            q = doc.add_paragraph(); q.paragraph_format.left_indent = Inches(0.4); q.paragraph_format.first_line_indent = Inches(-0.4)
            q.paragraph_format.space_after = Pt(3); q.paragraph_format.line_spacing = 1.0; q.alignment = WD_ALIGN_PARAGRAPH.LEFT
            runs(q, f"[{CIT[k]}] {R[k]}", 11)

# footer page number
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER; r = fp.add_run()
for tag, txt in (("begin", None), (None, "PAGE"), ("end", None)):
    if tag: e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), tag)
    else: e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt
    r._r.append(e)
r.font.name = FONT; r.font.size = Pt(11)
ARTICLE.parent.mkdir(parents=True, exist_ok=True)
doc.save(ARTICLE)
print("Saved", ARTICLE, "| references:", len(ORDER), "| equations:", len(EQN), "| tables:", len(TBN), "| figures:", len(FGN))
